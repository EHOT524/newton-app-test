"""Мост между страницей приложения и кодом бота: вопросы уходят на страницу в JSON, ответы проверяет бот."""

import json

from app.content import COURSES, LEVELS, PHYS
from app.questions import Question, build_lesson, build_review, check_typed

_QUESTIONS: dict[int, Question] = {}


def _pack(q: Question) -> dict:
    qid = len(_QUESTIONS)
    _QUESTIONS[qid] = q
    return {"id": qid, "kind": q.kind, "text": q.text, "key": q.key, "options": q.options, "correct": q.correct,
            "explanation": q.explanation, "answer": q.answer_text}


def info() -> str:
    return json.dumps({"modes": COURSES[PHYS].modes, "levels": LEVELS}, ensure_ascii=False)


def lesson(mode: str, level: str, size: int = 10) -> str:
    return json.dumps([_pack(q) for q in build_lesson("formulas", mode, size, level, PHYS)], ensure_ascii=False)


def review(keys: str, mode: str, level: str, size: int = 10) -> str:
    only_formulas = [k for k in json.loads(keys) if k.startswith("f:")]
    return json.dumps([_pack(q) for q in build_review(only_formulas, mode, size, level, PHYS)], ensure_ascii=False)


def check(qid: int, answer: str) -> bool:
    return check_typed(_QUESTIONS[qid], answer)
