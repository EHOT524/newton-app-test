"""Мост между страницей приложения и кодом бота: вопросы уходят на страницу в JSON, ответы проверяет бот."""

import json
import re
from html import escape

from app.content import (
    CLASS_MODES, COURSES, DEPENDENCIES, EXAM_CARDS, EXAM_NOTES, FORMULA_BY_ID, LEGEND, LEVELS, PASS_PERCENT, PHYS, STEPS, TERMS,
    UNITS, opened,
)
from app.questions import Question, build_lesson, build_path_step, build_review, check_typed, dependency_card, render_expr

_QUESTIONS: dict[int, Question] = {}
# Команды бота в приложении не работают, поэтому ссылки на /input из текста вопросов убираем
_INPUT_HINT = re.compile(r" ?(?:Весь список|Как писать остальные|Как вводить формулы): /input\.?")


def _pack(q: Question) -> dict:
    qid = len(_QUESTIONS)
    _QUESTIONS[qid] = q
    return {"id": qid, "kind": q.kind, "text": _INPUT_HINT.sub("", q.text), "key": q.key, "options": q.options,
            "correct": q.correct, "explanation": q.explanation, "answer": q.answer_text}


def _dump(questions: list[Question]) -> str:
    return json.dumps([_pack(q) for q in questions], ensure_ascii=False)


def info() -> str:
    return json.dumps({"modes": COURSES[PHYS].modes, "levels": LEVELS, "pass": PASS_PERCENT}, ensure_ascii=False)


def lesson(mode: str, level: str, path: str = "{}", size: int = 10) -> str:
    """Тренировка формул: в классе только то, что уже пройдено на пути, как в боте."""
    return _dump(build_lesson("formulas", mode, size, level, PHYS, opened(json.loads(path), PHYS, mode)))


def review(keys: str, mode: str, level: str, size: int = 10) -> str:
    return _dump(build_review(json.loads(keys), mode, size, level, PHYS))


def check(qid: int, answer: str) -> bool:
    return check_typed(_QUESTIONS[qid], answer)


# ---------- путь ----------

def path(mode: str) -> str:
    """Шаги пути для карты: в классе разделы с контрольной в конце, в ОГЭ и ЕГЭ номера заданий."""
    steps = [{"title": s.title, "unit": s.unit, "control": s.control, "number": s.number} for s in STEPS[mode]]
    units = [title for title, _ in UNITS[mode]] if mode in CLASS_MODES else []
    return json.dumps({"steps": steps, "units": units, "classes": mode in CLASS_MODES, "note": EXAM_NOTES.get(mode, "")},
                      ensure_ascii=False)


def _step_cards(step) -> list[str]:
    """Обучающая карточка, как в боте: ученик видит новое до вопросов, а не узнаёт его из ошибок."""
    terms = {t.term: t for t in TERMS}
    out = []
    for fid in step.formulas:
        f = FORMULA_BY_ID[fid]
        out.append(f"📐 <b>{escape(f.name)}</b>\n<b>{escape(render_expr(f.expr))}</b>\n{escape(LEGEND[fid])}")
    out += [f"📖 <b>{escape(name)}</b> — {escape(terms[name].definition)}" for name in step.terms]
    out += [f"🔗 {dependency_card(DEPENDENCIES[i])}" for i in step.deps]
    return out


def _exam_card(mode: str, step) -> list[str]:
    card = EXAM_CARDS[mode][step.number]
    out = [f"🎯 <b>Что проверяют</b>\n{escape(card.checks)}"]
    if card.formulas:
        out.append("📐 <b>Формулы</b>\n" + "\n".join(
            f"• {escape(FORMULA_BY_ID[i].name)}: <b>{escape(render_expr(FORMULA_BY_ID[i].expr))}</b>" for i in card.formulas))
    out += [f"🧭 <b>Как решать</b>\n{escape(card.plan)}", f"⚠️ <b>Частая ошибка</b>\n{escape(card.mistake)}"]
    return out


def card(mode: str, index: int) -> str:
    step = STEPS[mode][index]
    if step.control:
        cards = [f"🏁 Проверка по всему разделу. Чтобы раздел засчитался, нужно не меньше {PASS_PERCENT}% верных ответов."]
    elif mode in CLASS_MODES:
        cards = _step_cards(step)
    else:
        cards = _exam_card(mode, step)
    return json.dumps({"title": step.title, "cards": cards}, ensure_ascii=False)


def step_lesson(mode: str, index: int, level: str) -> str:
    """Урок шага, как кнопка «Начать урок» в боте: в классе с повтором пройденного раньше."""
    step = STEPS[mode][index]
    earlier = opened({mode: index}, PHYS, mode) if mode in CLASS_MODES else None
    size = 10 if step.control else 7 if mode in CLASS_MODES else 6
    return _dump(build_path_step(mode, step, level, earlier, size))


def skip_lesson(mode: str, unit: int, level: str) -> str:
    """«Я уже знаю этот раздел»: контрольная раздела без старых тем."""
    control = next(s for s in STEPS[mode] if s.unit == unit and s.control)
    return _dump(build_path_step(mode, control, level, None, 10))
