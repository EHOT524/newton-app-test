"""Проверка формул, введённых учеником с телефона или клавиатуры.

Ответ разбирается как математическое выражение и сравнивается с правильным
по значению: подставляем случайные числа вместо букв. Поэтому порядок множителей,
лишние скобки и запись 1/2*m*v^2 вместо m*v^2/2 не важны, а m*v/q*B и m*v/(q*B) — разные.
Формула, выраженная через другую букву (R = U/I вместо I = U/R), тоже верна.

Опечатки в словах прощаем, а русские буквы читаем так, как подходит к формуле:
Р — это R или P, Ф — F или Φ, л — l или λ.
"""

import itertools
import math
import random
import re

# Русские названия букв и слова; короткие заменяем только как отдельное слово
_WORDS = [
    (r"sqrt|sqr|(?:квадратный\s*)?корень\s*(?:из)?", "√"), (r"лямбда|lambda|lamda", "λ"), (r"дельта|delta", "Δ"), (r"омега|omega", "ω"),
    (r"альфа|alpha", "α"), (r"бета|beta", "β"), (r"гамма|gamma", "γ"), (r"[эеи]пс[иеы]лонд?(?![а-яё])|[эеи]пс[иеы]лон|epsilon", "ε"),
    (r"(?<![а-яё])кпд(?![а-яё])", "η"), (r"(?<![а-яё])ро(?=[жт]|(?![а-яё]))|rho", "ρ"),
    (r"(?<![а-яё])эта(?![а-яё])|(?<![a-z])eta", "η"), (r"(?<![а-яё])фи(?![а-яё])|phi", "φ"),
    (r"(?<![а-яё])пи(?![а-яё])|(?<![a-z])pi(?![a-z])", "π"), (r"(?<![а-яё])ню(?![а-яё])|(?<![a-z])nu(?![a-z])", "ν"),
    (r"(?<![а-яё])мю(?![а-яё])|(?<![a-z])mu(?![a-z])", "μ"),
    (r"(?<![а-яё])косинус(?![а-яё])", "cos"), (r"(?<![а-яё])синус(?![а-яё])", "sin"),
    (r"(?<![а-яё])(?:котангенс|ктг)(?![а-яё])", "ctg"), (r"(?<![а-яё])тангенс(?![а-яё])", "tg"),
    (r"(?<![а-яё])(?:логарифм|лог)(?![а-яё])", "log"), (r"(?<![а-яё])(?:сигма|sigma)(?![а-яё])", "σ"),
    (r"(?<![а-яё])к[ую](?![а-яё])", "Q"),
    # Слова вместо знаков и индексов: «v в квадрате», «эпсилон нулевое», «R один»
    (r"\s*(?:в\s*)?квадрат[а-яё]*", "^2"), (r"\s*(?:в\s*)?куб[а-яё]*", "^3"),
    (r"(?<![а-яё])плюс(?![а-яё])", "+"), (r"(?<![а-яё])минус(?![а-яё])", "-"),
    (r"(?<![а-яё])равн[а-яё]*(?![а-яё])", "="), (r"(?<![а-яё])умнож[а-яё]*(?:\s+на(?![а-яё]))?", "*"),
    (r"(?<![а-яё])(?:раз|по)?дел[а-яё]*\s+на(?![а-яё])", "/"),
    (r"(?<![а-яё])(?:нулев[а-яё]*|ноль|нуль)(?![а-яё])", "0"),
    (r"(?<![а-яё])(?:один|одно|перв[а-яё]{2})(?![а-яё])", "1"), (r"(?<![а-яё])(?:два|две|втор[а-яё]{2})(?![а-яё])", "2"),
    (r"(?<![а-яё])(?:три|трет[а-яё]{2})(?![а-яё])", "3"), (r"(?<![а-яё])четыре(?![а-яё])", "4"),
]
_WORDS = [(re.compile(p, re.I), s) for p, s in _WORDS]

# Слова, в которых прощаем опечатки: лямда, омга, корен
_TYPOS = {"лямбда": "λ", "дельта": "Δ", "омега": "ω", "альфа": "α", "бета": "β", "гамма": "γ", "эпсилон": "ε",
          "корень": "√", "синус": "sin", "косинус": "cos", "нулевое": "0"}
_RUN = re.compile(r"[а-яё]{4,}", re.I)

_CHARS = str.maketrans({
    # кириллица, похожая на латиницу, и буквы, которых нет на клавиатуре
    "а": "a", "в": "v", "е": "e", "к": "k", "м": "m", "н": "h", "о": "o", "р": "p", "с": "c", "т": "t",
    "у": "y", "х": "x", "г": "g", "д": "d", "А": "A", "В": "B", "Е": "E", "К": "K", "М": "M", "Н": "H",
    "О": "O", "Р": "P", "С": "C", "Т": "T", "У": "Y", "Х": "X", "л": "λ", "п": "π", "ф": "φ", "Ф": "Φ",
    "Г": "Γ", "Д": "Δ", "ш": "ω", "w": "ω", "Ω": "ω", "з": "z", "З": "Z", "б": "b", "Б": "B", "и": "i", "И": "I",
    # греческие → как их обычно набирают
    "υ": "v", "ν": "v", "ρ": "p", "η": "n", "ε": "e", "ℰ": "E", "Ε": "E", "ϕ": "φ", "ɸ": "φ", "∆": "Δ", "δ": "Δ",
    "μ": "u", "γ": "y", "α": "a", "β": "b",
    # индексы, степени и знаки
    "₀": "0", "₁": "1", "₂": "2", "₃": "3", "₄": "4", "₅": "5", "₆": "6", "₇": "7", "₈": "8", "₉": "9",
    "ₐ": "A", "ₙ": "n", "⁰": "^0", "¹": "^1", "²": "^2", "³": "^3", "⁴": "^4",
    "−": "-", "–": "-", "—": "-", "÷": "/", ":": "/", "’": "'", "`": "'", "·": "*", "×": "*", "∙": "*",
    "⋅": "*", "•": "*", "[": "(", "]": ")", "{": "(", "}": ")", "\\": "/", "½": "(1/2)", ";": "",
})
# Как ещё можно прочитать букву, если в формуле есть такая величина
_READINGS = {"в": "vb", "н": "nh", "р": "rp", "с": "sc", "х": "xh", "у": "uy", "л": "l", "п": "p", "ф": "f", "г": "g",
             "д": "d", "б": "b", "и": "i", "е": "e", "о": "0", "o": "0"}
# Другие записи индексов: Eпот, Ekin, Fт, Umax
_INDEX = {
    "к": "кин kin", "п": "пот pot пол pol", "з": "зат zat", "н": "нагр nagr n", "х": "хол hol x", "тр": "т t tr",
    "тяж": "т t tyazh tyaj", "упр": "у u уп up upr", "А": "a арх arh", "вых": "в v vyh vih", "ст": "st", "д": "d",
    "м": "m max макс мах", "кр": "k к kr", "ж": "zh", "ср": "sr", "пт": "т pt", "пр": "pr",
}
_LOOKALIKE = {"F": "FФ", "E": "EЕ", "A": "AА", "P": "PР", "T": "TТ", "U": "UУ", "I": "IИ", "V": "VВ", "υ": "υvв",
              "ρ": "ρрp", "λ": "λл", "α": "αa"}
_INDEXED = re.compile(r"([A-Za-zαλρυ])([а-яА]+)$")
_TRIG_WORD = re.compile(r"(sin|cos|ctg|tg)\((?!\d)([^()+\-*/]*)\)")
_FUNCS = ("sin", "cos")
# Читаем как функции, только если они есть в правильной формуле: в физике tg — это t·g
_MATH_FUNCS = ("ctg", "tg", "log", "ln", "lg")
_FUNC_VALUES = {"sin": math.sin, "cos": math.cos, "tg": math.tan, "ctg": lambda x: 1 / math.tan(x), "ln": math.log, "lg": math.log10}
_CYR_INDEX = re.compile(r"^([A-Za-zυ])[а-яА]+$")  # Eк, Fтр, FА — индекс по-русски
_NUMBER = re.compile(r"\d+(?:[.,]\d+)?")


def lev(a: str, b: str) -> int:
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def _fix_typo(m: re.Match) -> str:
    word = m.group().lower()
    best = min(_TYPOS, key=lambda w: lev(word, w))
    return _TYPOS[best] if lev(word, best) <= (1 if len(best) < 5 else 2) else m.group()


def _replace_words(s: str) -> str:
    for pattern, sym in _WORDS:
        s = pattern.sub(sym, s)
    return _RUN.sub(_fix_typo, s)


def _normalize(s: str) -> str:
    s = re.sub(r"(?<=[A-Za-z])п", "p", s)  # индекс Aп, а не умножение на π
    s = s.translate(_CHARS).replace("**", "^").replace("==", "=")
    s = re.sub(r"[\s_]", "", s).rstrip(".,!?")
    return re.sub(r"(?<!\d)\.|\.(?!\d)", "*", s)


def prepare(s: str) -> str:
    return _normalize(_replace_words(s.strip()))


def _with_indexes(s: str, expr: str) -> str:
    """Eпот → Eп, Ftr → Fтр: только для индексов, которые есть в этой формуле."""
    for tok in expr.split(" "):
        m = _INDEXED.search(tok)
        if not m or tok.startswith(("sin", "cos")) and m.group(1) != "α":
            continue
        letter, index = m.groups()
        names = sorted({index, *_INDEX.get(index, "").split()}, key=len, reverse=True)
        pattern = f"[{_LOOKALIKE.get(letter, letter)}](?:{'|'.join(names)})(?![а-яёa-z])"
        s = re.sub(pattern, letter + index, s, flags=re.I)
    return s


def _readings(s: str, expr: str):
    """Варианты ответа, где русские буквы заменены на величины этой формулы."""
    symbols = set(re.sub(r"sin|cos", "", prepare(expr)))
    choices = []
    for c in s:  # каждое вхождение отдельно: в С = ε·ε₀·С/д первая С — это C, вторая — S
        options = [c]
        for latin in _READINGS.get(c.lower(), ""):
            found = [x for x in symbols if x.lower() == latin]
            same_case = [x for x in found if x == (latin.upper() if c.isupper() else latin)]
            options += same_case or found
        choices.append(list(dict.fromkeys(options)))
    yield from map("".join, itertools.islice(itertools.product(*choices), 256))


def _balanced(s: str) -> str | None:
    """Забытая в конце скобка — опечатка; лишняя тоже."""
    open_count = s.count("(") - s.count(")")
    if open_count > 0:
        return s + ")" * open_count
    return s[:open_count] if open_count and s.endswith(")" * -open_count) else s if not open_count else None


def known_symbols(expr: str) -> set[str]:
    """Буквенные обозначения правильной формулы: Ftp, v0, Imax, m1…"""
    out = set()
    for tok in expr.split(" "):
        tok = prepare(tok).split("^")[0]
        for f in _FUNCS:
            tok = tok.removeprefix(f)
        func = next((f for f in _MATH_FUNCS if tok.startswith(f)), None)
        if func:
            out.add(func)
            tok = tok.removeprefix(func)
        if tok and not _NUMBER.fullmatch(tok) and tok not in tuple("=*/+-()√"):
            out.add(tok)
    return out


def _lex(s: str, known: list[str]) -> list[tuple[str, str]]:
    out, i = [], 0
    while i < len(s):
        c = s[i]
        if c in "+-*/()^√":
            out.append(("op", c))
            i += 1
            continue
        m = _NUMBER.match(s, i)
        if m:
            # r2 — ученик мог написать квадрат без ^
            if out and out[-1][0] == "sym" and c != "0" and s[m.end():m.end() + 1] != "%":
                out.append(("op", "^"))
            out.append(("num", m.group().replace(",", ".")))
            i = m.end()
            continue
        func = next((f for f in _FUNCS if s.startswith(f, i)), None)
        if func:
            out.append(("func", func))
            i += len(func)
            continue
        sym = next((k for k in known if s.startswith(k, i)), c)
        out.append(("func" if sym in _MATH_FUNCS else "sym", sym))
        i += len(sym)
    return out


class _Parser:
    def __init__(self, toks, env):
        self.toks, self.env, self.i = toks, env, 0

    def peek(self):
        return self.toks[self.i] if self.i < len(self.toks) else (None, None)

    def take(self):
        self.i += 1
        return self.toks[self.i - 1]

    def expr(self):
        val = self.term()
        while self.peek() in (("op", "+"), ("op", "-")):
            val = val + self.term() if self.take()[1] == "+" else val - self.term()
        return val

    def term(self):
        val = self.unary()
        while True:
            kind, v = self.peek()
            if (kind, v) == ("op", "*"):
                self.take()
                val *= self.unary()
            elif (kind, v) == ("op", "/"):
                self.take()
                val /= self.unary()
            elif kind in ("num", "sym", "func") or v in ("(", "√"):
                val *= self.unary()  # умножение без знака: mgh, 2π
            else:
                return val

    def unary(self):
        if self.peek() == ("op", "-"):
            self.take()
            return -self.unary()
        return self.power()

    def power(self):
        val = self.atom()
        if self.peek() == ("op", "^"):
            self.take()
            val **= self.unary()
        return val

    def function(self, name):
        power = 1.0
        if self.peek() == ("op", "^"):  # sin²α
            self.take()
            power = self.atom()
        if name == "log":
            base = self.atom()
            return (math.log(self.argument()) / math.log(base)) ** power
        return _FUNC_VALUES[name](self.argument()) ** power

    def argument(self):
        kind, val = self.peek()[0], self.atom()
        if kind == "num" and self.peek()[0] == "sym":  # sin2α
            val *= self.atom()
        return val

    def atom(self):
        kind, v = self.take()
        if kind == "num":
            return float(v)
        if kind == "sym":
            return self.env(v)
        if kind == "func":
            return self.function(v)
        if v == "√":
            return math.sqrt(abs(self.atom()))  # знак под корнем зависит от подставленных чисел
        if v == "(":
            val = self.expr()
            if self.take() != ("op", ")"):
                raise ValueError
            return val
        raise ValueError


def _value(side: str, known: list[str], seed: int) -> float | None:
    # Одна и та же буква получает одно и то же число независимо от порядка в выражении
    # Знак % ни на что не влияет: и *100%, и *100 — верная запись
    env = lambda name: 1.0 if name in "%°" else random.Random(f"{seed}:{name}").uniform(1.1, 3.0)
    try:
        p = _Parser(_lex(side, known), env)
        val = p.expr()
        return None if p.i != len(p.toks) or isinstance(val, complex) else val
    except (ValueError, IndexError, ArithmeticError):
        return None


def _same(a: str, b: str, known: list[str]) -> bool:
    for seed in (1, 2, 3):
        x, y = _value(a, known, seed), _value(b, known, seed)
        if x is None or y is None or not math.isclose(x, y, rel_tol=1e-9, abs_tol=1e-12):
            return False
    return True


def _identity(right: list[str], known: list[str]) -> bool:
    """Тождество вроде (a + b)² = a² + 2ab + b²: левая и правая части равны при любых числах."""
    return len(right) > 1 and all(_same(right[0], side, known) for side in right[1:])


def _rearranged(answer: list[str], right: list[str], known: list[str]) -> bool:
    """То же равенство, выраженное иначе: U = I*R из I = U/R, v² = 2*a*s из v = √(2*a*s)."""
    letters = lambda sides: {v for side in sides for kind, v in _lex(side, known) if kind == "sym"}
    if letters(answer) != letters(right) or _identity(right, known):  # ρ и p записаны одинаково, поэтому сокращать их нельзя
        return False
    values = [[_value(x, known, seed) for x in (*answer, *right)] for seed in (1, 2, 3)]
    if any(v is None for row in values for v in row):
        return False
    close = lambda pairs: all(math.isclose(x, y, rel_tol=1e-9, abs_tol=1e-12) for x, y in pairs)
    if close((a - b, c - d) for a, b, c, d in values) or close((a - b, d - c) for a, b, c, d in values):
        return True
    if any(b == 0 or d == 0 or c == 0 for _, b, c, d in values):
        return False
    if close((a / b, c / d) for a, b, c, d in values) or close((a / b, d / c) for a, b, c, d in values):
        return True
    if any(a / b <= 0 or c / d <= 0 for a, b, c, d in values):
        return False
    return any(close((a / b, (c / d) ** e) for a, b, c, d in values) for e in (2, -2, 0.5, -0.5))


def _sides_match(answer: list[str], right: list[str], known: list[str]) -> bool:
    if len(answer) == 1:  # ученик мог написать только правую часть
        return not _identity(right, known) and _same(answer[0], right[-1], known)
    if len(answer) != len(right):
        return False
    if any(all(_same(a, r, known) for a, r in zip(answer, perm)) for perm in itertools.permutations(right)):
        return True
    return len(right) == 2 and _rearranged(answer, right, known)


def _variants(expr: str) -> list[str]:
    """Формула и она же с левой частью без русского индекса: E = m·v²/2."""
    out = [expr]
    lhs, _, rhs = expr.partition(" = ")
    m = _CYR_INDEX.match(lhs)
    if m and rhs:
        out.append(f"{m.group(1)} = {rhs}")
    return out


def _has_case_clash(known: set[str]) -> bool:
    return len({k.lower() for k in known}) != len(known)


def _matches_expr(answer: str, expr: str, known: set[str], right: list[str]) -> bool:
    answer = _balanced(_TRIG_WORD.sub(r"\1\2", _normalize(answer)))
    if not answer:
        return False
    # Телефон сам делает первую букву заглавной
    candidates = [answer, answer[0].lower() + answer[1:]]
    strict = sorted(known, key=len, reverse=True)
    if any(_sides_match(c.split("="), right, strict) for c in candidates):
        return True
    # Регистр важен, только если в формуле есть обе буквы: T и t, R и r
    if _has_case_clash(known):
        return False
    folded = sorted({k.lower() for k in known}, key=len, reverse=True)
    return _sides_match(answer.lower().split("="), [r.lower() for r in right], folded)


# ---------- логические формулы: сравниваем таблицы истинности ----------

LOGIC_SIGNS = "¬∧∨→≡⊕"
_LOGIC_OPS = (("<->", "≡"), ("<=>", "≡"), ("==", "≡"), ("↔", "≡"), ("⇔", "≡"), ("->", "→"), ("=>", "→"), ("⇒", "→"),
              ("/\\", "∧"), ("\\/", "∨"), ("xor", "⊕"), ("and", "∧"), ("not", "¬"), ("или", "∨"), ("or", "∨"), ("не", "¬"),
              ("и", "∧"), ("&", "∧"), ("*", "∧"), ("·", "∧"), ("|", "∨"), ("+", "∨"), ("!", "¬"), ("~", "¬"), ("^", "⊕"))
_LOGIC_LATIN = str.maketrans({"а": "a", "в": "b", "с": "c", "е": "e", "х": "x"})
_LOGIC_LEVELS = (("≡",), ("→",), ("∨", "⊕"), ("∧",))


def is_logic(expr: str) -> bool:
    return any(c in expr for c in LOGIC_SIGNS)


def _logic_tokens(s: str) -> list[str]:
    s, out = re.sub(r"\s", "", s.lower()), []
    while s:
        op = next(((text, sign) for text, sign in _LOGIC_OPS if s.startswith(text)), None)
        if op:
            out.append(op[1])
            s = s[len(op[0]):]
        else:
            out.append(s[0].translate(_LOGIC_LATIN).upper())
            s = s[1:]
    return out


def _logic_apply(op: str, a: bool, b: bool) -> bool:
    return {"≡": a == b, "→": not a or b, "∨": a or b, "⊕": a != b, "∧": a and b}[op]


class _Logic:
    """Приоритет как в школьном курсе: НЕ, И, ИЛИ, следование, эквиваленция."""

    def __init__(self, toks: list[str], env: dict[str, bool]):
        self.toks, self.env, self.i = toks, env, 0

    def peek(self):
        return self.toks[self.i] if self.i < len(self.toks) else None

    def take(self):
        self.i += 1
        return self.toks[self.i - 1]

    def level(self, depth: int = 0) -> bool:
        if depth == len(_LOGIC_LEVELS):
            return self.atom()
        val = self.level(depth + 1)
        ops = _LOGIC_LEVELS[depth]
        while self.peek() in ops or ("∧" in ops and self.peek() not in (None, ")", *LOGIC_SIGNS)) or ("∧" in ops and self.peek() == "¬"):
            op = self.take() if self.peek() in ops else "∧"  # AB — это A и B
            val = _logic_apply(op, val, self.level(depth + 1))
        return val

    def atom(self) -> bool:
        t = self.take()
        if t == "¬":
            return not self.atom()
        if t == "(":
            val = self.level()
            if self.take() != ")":
                raise ValueError
            return val
        if t in ("0", "1"):
            return t == "1"
        if t.isalpha() and t.isascii():
            return self.env[t]
        raise ValueError


def _logic_table(toks: list[str], names: list[str]) -> tuple[bool, ...] | None:
    out = []
    try:
        for row in itertools.product((False, True), repeat=len(names)):
            parser = _Logic(toks, dict(zip(names, row)))
            val = parser.level()
            if parser.peek() is not None:
                return None
            out.append(val)
    except (ValueError, IndexError, KeyError):
        return None
    return tuple(out)


def _logic_matches(answer: str, exprs: list[str]) -> bool:
    answer = answer.strip().rstrip(".!?")
    for expr in exprs:
        right = [_logic_tokens(x) for x in expr.split(" = ")]
        given = [_logic_tokens(x) for x in re.split(r"(?<![<=!])=(?![=>])", answer)]
        if len(given) != len(right) or (len(given) == 2 and given[0] == given[1]) or not all(given):
            continue  # A ∨ ¬A = A ∨ ¬A переписывает левую часть и ничего не доказывает
        names = sorted({t for side in (*right, *given) for t in side if t.isalpha() and t.isascii()})
        if len(names) > 6:
            continue
        ours, theirs = [_logic_table(x, names) for x in right], [_logic_table(x, names) for x in given]
        if None not in theirs and (ours == theirs or ours == theirs[::-1]):
            return True
    return False


def formula_matches(answer: str, exprs: list[str]) -> bool:
    if is_logic(exprs[0]):
        return _logic_matches(answer, exprs)
    words = _replace_words(answer.strip())
    for expr in (v for e in exprs for v in _variants(e)):
        known = known_symbols(expr)
        right = [_TRIG_WORD.sub(r"\1\2", prepare(x)) for x in expr.split(" = ")]
        if any(_matches_expr(r, expr, known, right) for r in _readings(_with_indexes(words, expr), expr)):
            return True
    return False


def _token(s: str) -> str:
    return _TRIG_WORD.sub(r"\1\2", _normalize(s)).replace("^", "")


def token_matches(answer: str, hidden: str, formula_tokens: list[str]) -> bool:
    h = _token(_replace_words(hidden))
    others = {_token(_replace_words(t)) for t in formula_tokens} - {h}
    expr = " ".join(formula_tokens)
    for reading in _readings(_with_indexes(_replace_words(answer.strip()), expr), expr):
        a = _token(reading)
        if a == h or (h.endswith(("%", "°")) and a == h[:-1]):
            return True
        if a.lower() == h.lower() and a not in others and a.lower() not in {o.lower() for o in others}:
            return True
    return False


# ---------- как набрать формулу ----------

PERCENT = " · 100%"
_TYPED = str.maketrans({
    "·": "*", "²": "^2", "³": "^3", "−": "-", "√": "sqrt", "π": "pi", "₀": "0", "₁": "1", "₂": "2", "₃": "3",
    "ₐ": "A", "ₙ": "n", "ℰ": "E", "ω": "w", "υ": "v",
})


def _wrap(toks: list[str]) -> str:
    text = "".join(toks)
    return text if len(toks) == 1 or (toks[0] == "(" and toks[-1] == ")" and text.count("(") == 1) else f"({text})"


def _typed_term(toks: list[str]) -> str:
    depth, slash = 0, None
    for i, t in enumerate(toks):
        depth += (t == "(") - (t == ")")
        if t == "/" and depth == 0:
            slash = slash or i
    if slash is None or slash == 0:
        return "".join(toks)
    return f"{_wrap(toks[:slash])}/{_wrap(toks[slash + 1:])}"


_LOGIC_TYPED = {"¬": "не", "∧": "и", "∨": "или", "→": "->", "≡": "==", "⊕": "xor"}


def typed_form(expr: str) -> str:
    """Запись формулы так, как её набирают: числитель и знаменатель в скобках."""
    if is_logic(expr):
        return " ".join(_LOGIC_TYPED.get(t, t) for t in expr.split(" ")).replace("( ", "(").replace(" )", ")")
    sides = []
    for side in expr.split(" = "):
        percent = side.endswith(PERCENT)  # 100% умножается на всю дробь, а не входит в знаменатель
        side = side.removesuffix(PERCENT)
        toks, terms, cur, depth = side.split(" "), [], [], 0
        for t in toks:
            depth += (t == "(") - (t == ")")
            if t in ("+", "−") and depth == 0 and cur:
                terms += [_typed_term(cur), t]
                cur = []
            else:
                cur.append(t)
        terms.append(_typed_term(cur))
        sides.append("".join(terms) + ("*100%" if percent else ""))
    return " = ".join(sides).translate(_TYPED)
