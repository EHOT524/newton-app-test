from ..formulas import Formula
from ..problems import Problem
from ..terms import Term
from .dependencies import MATH_DEPENDENCIES
from .exam import EXAM_NUMERIC, position
from .formulas import MATH_FORMULAS, NOT_IN_BASE
from .numeric import MATH_NUMERIC as _BASE_NUMERIC
from .problems import MATH_PROBLEMS
from .terms import MATH_TERMS

MATH_NUMERIC = [*_BASE_NUMERIC, *EXAM_NUMERIC]

MATH_TOPICS = {
    "alg": "🔢 Числа и выражения",
    "eq": "⚖️ Уравнения и неравенства",
    "word": "🚆 Текстовые задачи",
    "seq": "🪜 Прогрессии",
    "func": "📈 Функции и графики",
    "trig": "📏 Тригонометрия",
    "log": "🧮 Степени и логарифмы",
    "calc": "📉 Производная и первообразная",
    "geo": "📐 Планиметрия",
    "ster": "🧊 Стереометрия",
    "prob": "🎲 Вероятность и статистика",
    "sets": "🧩 Множества, графы и логика",
}

# ЕГЭ база: нет тем, которые в кодификаторе отмечены только углублённым уровнем.
# Тела вращения оставлены: в кодификаторе они углублённые, но в демоварианте базы есть
TERMS_NOT_IN_BASE = {"комплексное число", "определитель матрицы", "асимптота", "вектор", "скалярное произведение",
                     "сочетание", "перестановка", "математическое ожидание", "стандартное отклонение"}


def in_ege_base(item) -> bool:
    if isinstance(item, Formula):
        return item.id not in NOT_IN_BASE
    if isinstance(item, Term):
        return item.term not in TERMS_NOT_IN_BASE
    if isinstance(item, Problem):
        return not set(item.formulas) & NOT_IN_BASE
    return True


# План вариантов: одна строка — один номер экзамена, в порядке демовариантов 2027.
# Строка — кортеж задач или разделов; список — блок, который занимает несколько номеров подряд
# (задания 1–5 ОГЭ связаны одной темой). Развёрнутая часть не входит: её бот проверить не может.
_FACTS = ("m_fact1", "m_fact2", "m_fact3", "m_fact4", "m_fact5", "m_fact6")
_VECTORS = ("m_g43", "m_g44", "m_g46")
_RANDOM_VALUE = ("m_p22", "m_p23", "m_p24")
_OGE_BLOCK = [tuple(f"o1_t{n}" for n in range(1, 6)), tuple(f"o1_p{n}" for n in range(1, 6))]
MATH_VARIANTS = {
    "oge": [_OGE_BLOCK, position("xa"), position("o7"), position("o8"), position("o9"), position("o10"), position("o11"),
            position("xf"), position("o13"), position("o14"), position("o15"), position("o16"), position("o17"),
            position("o18"), position("o19") + _FACTS],
    "ege_base": [position("b1"), position("b2"), position("b3"), position("xf"), position("b5"), position("b6"), position("b7"),
                 position("b8"), position("b9"), position("b10"), position("b11"), position("b12"), position("b13"),
                 position("xa"), position("b15"), position("b16"), position("b17"), position("b18"), position("b19"),
                 position("b20"), position("b21")],
    "ege": [position("p1"), position("p2") + _VECTORS, position("p3"), position("p4"), position("p5"),
            position("p6") + _RANDOM_VALUE, position("p7"), position("p8"), position("p9") + ("m_d3", "m_d5", "m_d6"),
            position("p10"), position("p11"), position("p12"), position("p13")],
}
