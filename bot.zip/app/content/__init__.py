from dataclasses import dataclass

from .dependencies import DEPENDENCIES, RELATIONS, SHORT, Dependency
from .formulas import FORMULA_BY_ID, FORMULAS, Formula
from .informatics import INFO_DEPENDENCIES, INFO_FORMULAS, INFO_NUMERIC, INFO_PROBLEMS, INFO_TERMS, INFO_TOPICS, INFO_VARIANTS
from .mathematics import (
    MATH_DEPENDENCIES, MATH_FORMULAS, MATH_NUMERIC, MATH_PROBLEMS, MATH_TERMS, MATH_TOPICS, MATH_VARIANTS, in_ege_base,
)
from .numeric import NUMERIC, NUMERIC_BY_ID, PI_NOTE, Numeric
from .physics_cards import LEGEND
from .physics_exam import PHYSICS_EXAM, PHYSICS_VARIANTS
from .physics_exam_cards import EXAM_CARDS
from .physics_path import CLASS_MODES, DEP_KEYS, EXAM_NOTES, PASS_PERCENT, STEPS, UNITS, Opened, Step, beginner, done_steps, has_path, opened, unit_title
from .problems import PROBLEMS, Problem
from .statements import STATEMENTS, Statement
from .terms import TERMS, Term

# Сложность: в лёгком и среднем ответ выбирают из вариантов, в сложном пишут сами
LEVELS = {"easy": "🟢 Лёгкий", "medium": "🟡 Средний", "hard": "🔴 Сложный"}
LEVEL_OPTIONS = {"easy": 4, "medium": 8, "hard": 0}

# Режимы обучения: классы 7–11, ОГЭ (материал 7–9 без тем вне экзамена), ЕГЭ (всё)
MODES = {
    "7": "7 класс",
    "8": "8 класс",
    "9": "9 класс",
    "10": "10 класс",
    "11": "11 класс",
    "oge": "ОГЭ",
    "ege": "ЕГЭ",
}
MATH_MODES = {**MODES, "ege": "ЕГЭ профиль", "ege_base": "ЕГЭ база"}
EXAMS = ("oge", "ege", "ege_base")


TOPICS = {
    "mech": "⚙️ Механика",
    "mol": "🌡 Молекулярная физика и термодинамика",
    "el": "⚡ Электродинамика",
    "osc": "〰️ Колебания и волны",
    "opt": "🔦 Оптика",
    "quant": "⚛️ Квантовая и ядерная физика",
}


PHYS, MATH, INFO = "phys", "math", "info"
SUBJECTS = {PHYS: "🍎 Физика", MATH: "📐 Математика", INFO: "💻 Информатика"}
SUBJECT_STUDY = {PHYS: "физикой", MATH: "математикой", INFO: "информатикой"}


@dataclass(frozen=True)
class Course:
    formulas: list[Formula]
    terms: list[Term]
    deps: list[Dependency]
    problems: list[Problem]
    numeric: list[Numeric]
    topics: dict[str, str]
    modes: dict[str, str]
    variants: dict[str, list]


COURSES = {
    PHYS: Course(FORMULAS, TERMS, DEPENDENCIES, PROBLEMS, [*NUMERIC, *PHYSICS_EXAM], TOPICS, MODES, PHYSICS_VARIANTS),
    MATH: Course(MATH_FORMULAS, MATH_TERMS, MATH_DEPENDENCIES, MATH_PROBLEMS, MATH_NUMERIC, MATH_TOPICS, MATH_MODES, MATH_VARIANTS),
    INFO: Course(INFO_FORMULAS, INFO_TERMS, INFO_DEPENDENCIES, INFO_PROBLEMS, INFO_NUMERIC, INFO_TOPICS, MODES, INFO_VARIANTS),
}
FORMULA_BY_ID.update({f.id: f for f in (*MATH_FORMULAS, *INFO_FORMULAS)})
NUMERIC_BY_ID.update({t.id: t for t in (*MATH_NUMERIC, *PHYSICS_EXAM, *INFO_NUMERIC)})


def subject_of(u) -> str:
    return (u["subject"] if u else None) or PHYS


def mode_title(u) -> str:
    return COURSES[subject_of(u)].modes.get(u["mode"], "—")


def in_mode(item, mode: str) -> bool:
    if mode == "ege":
        return True
    if mode == "ege_base":
        return in_ege_base(item)
    if mode == "oge":
        return item.oge
    return int(mode) in item.grades


def formulas_for(mode: str, subject: str = PHYS) -> list[Formula]:
    return [f for f in COURSES[subject].formulas if in_mode(f, mode)]


def terms_for(mode: str, subject: str = PHYS) -> list[Term]:
    return [t for t in COURSES[subject].terms if in_mode(t, mode)]


def deps_for(mode: str, subject: str = PHYS) -> list[Dependency]:
    return [d for d in COURSES[subject].deps if in_mode(d, mode)]


def problems_for(mode: str, subject: str = PHYS) -> list[Problem]:
    return [p for p in COURSES[subject].problems if in_mode(p, mode)]


def numeric_topic(t: Numeric) -> str:
    return t.topic or FORMULA_BY_ID[t.formulas[0]].topic


def numeric_for(mode: str, topic: str | None = None, subject: str = PHYS) -> list[Numeric]:
    """Задача есть в режиме, только если в нём есть все её формулы."""
    return [t for t in COURSES[subject].numeric if all(in_mode(FORMULA_BY_ID[f], mode) for f in t.formulas)
            and topic in (None, numeric_topic(t)) and (not t.exams or mode in t.exams)]
