"""Задания по номерам демовариантов ОГЭ и ЕГЭ 2027. Числа случайные, ответ всегда число.

Рисунки и файлы заменены текстом. Не вошли задания, которые бот проверить не может:
ОГЭ 11–15 (работа с файлами), ЕГЭ 1, 3, 18, 27 (нужны рисунок, база данных или большой файл).
"""

import heapq
import itertools
import math
import random
import re
from dataclasses import replace
from functools import lru_cache

from ..numeric import Numeric
from ..numeric import T as _T


def E(id, topic, exam, text, answer, unit="", check=None, how="", derive=None, **ranges):
    return replace(_T(id, (), text, answer, unit, check, **ranges), exams=(exam,), topic=topic, how=how, derive=derive)


LETTERS = "ABCDEF"
CODES = {1: "~", 2: "#", 3: "# +", 4: "+ ~ #", 5: "+ #", 6: "~ #"}
ALPHABETS = ("АКЦЕНТ", "ГРАНИТ", "ПОМЕСТ", "ВЕРСТА")
EXPRESSIONS = (("((x ≡ ¬y) → ¬(w → x)) ∨ ¬z", lambda w, x, y, z: (not (x == (not y)) or not (not w or x)) or not z),
               ("(x ∧ ¬y) ∨ (z → w)", lambda w, x, y, z: (x and not y) or (not z or w)),
               ("(x → y) ∧ (z ≡ w)", lambda w, x, y, z: (not x or y) and z == w),
               ("¬(x ∨ y) ∨ (z ∧ w)", lambda w, x, y, z: (not (x or y)) or (z and w)),
               ("(x ≡ y) → (w ∧ ¬z)", lambda w, x, y, z: not x == y or (w and not z)))
FANO_WORDS = ("КОЛОБОК", "ЛОКОН", "КЛОБОК", "БОЛОНОК")


def shortest(edges: dict, start, finish) -> float | None:
    """Дейкстра по рёбрам {(откуда, куда): вес}."""
    best, queue = {start: 0}, [(0, str(start), start)]
    while queue:
        dist, _, node = heapq.heappop(queue)
        if node == finish:
            return dist
        for (a, b), w in edges.items():
            if a == node and dist + w < best.get(b, math.inf):
                best[b] = dist + w
                heapq.heappush(queue, (dist + w, str(b), b))
    return None


def _roads(seed) -> dict:
    rng, edges = random.Random(seed), {}
    for a, b in itertools.combinations(LETTERS, 2):
        if rng.random() < 0.55:
            edges[a, b] = edges[b, a] = rng.randint(1, 15)
    return edges


def _roads_text(seed) -> str:
    return ", ".join(f"{a}–{b}: {w}" for (a, b), w in _roads(seed).items() if a < b)


def _word(seed) -> list[int]:
    rng = random.Random(seed)
    return [rng.randint(1, 6) for _ in range(rng.randint(3, 4))]


def _message(seed) -> list[str]:
    return " ".join(CODES[d] for d in _word(seed)).split(" ")


def decodings(symbols: list[str]) -> int:
    ways = [1] + [0] * len(symbols)
    for i in range(len(symbols)):
        for code in CODES.values():
            part = code.split(" ")
            if symbols[i:i + len(part)] == part:
                ways[i + len(part)] += ways[i]
    return ways[-1]


def run_program(start, mul, add, commands) -> int:
    for c in commands:
        start = start * mul if c == "1" else start + add
    return start


def programs(start, finish, mul, add) -> list[str]:
    return ["".join(p) for size in range(1, 6) for p in itertools.product("12", repeat=size)
            if run_program(start, mul, add, p) == finish]


def _commands(p) -> str:
    return format(p, "05b").translate(str.maketrans("01", "12"))


def _pairs(seed) -> list[tuple[int, int]]:
    rng = random.Random(seed)
    return [(rng.randint(-12, 12), rng.randint(-12, 12)) for _ in range(9)]


def parameter(pairs, limit, wanted) -> int | None:
    """Наименьшее целое A, при котором условие s > limit или t > A верно wanted раз."""
    for a in range(-20, 21):
        if sum(s > limit or t > a for s, t in pairs) == wanted:
            return a
    return None


def _url(seed):
    rng = random.Random(seed)
    parts = [rng.choice(("http", "https", "ftp")), "://", rng.choice(("tt.", "doc.", "edu.")), rng.choice(("com", "ru", "net")), "/",
             rng.choice(("com.", "data.", "edu.")), rng.choice(("xls", "txt", "pdf"))]
    numbers = rng.sample(range(1, 8), 7)
    listed = sorted(zip(numbers, parts))
    return parts, numbers, ", ".join(f"{n}) {p}" for n, p in listed)


def _dag(seed) -> list[tuple[str, str]]:
    rng, names = random.Random(seed), "ABCDEFG"
    return [(a, b) for a, b in itertools.combinations(names, 2) if rng.random() < 0.5]


def count_paths(edges, start, finish) -> int:
    paths = {start: 1}
    for node in sorted({b for _, b in edges}):
        paths[node] = paths.get(node, 0) + sum(paths.get(a, 0) for a, b in edges if b == node)
    return paths.get(finish, 0)


def _stream(seed, digit) -> list[int]:
    rng = random.Random(seed)
    return [rng.randint(64, 720) * 8 + digit if rng.random() < 0.5 else rng.randint(100, 5000) for _ in range(7)]


def octal_hits(numbers, digit) -> int:
    return sum(len(oct(x)) - 2 == 4 and x % 8 == digit for x in numbers)


def _is_prime(n) -> bool:
    return n > 1 and all(n % d for d in range(2, math.isqrt(n) + 1))


def fano_length(word) -> int:
    known = {"Б": "00", "Н": "010", "Л": "111"}
    words = ["".join(b) for size in range(1, 5) for b in itertools.product("01", repeat=size)]
    prefix = lambda codes: any(a != b and b.startswith(a) for a in codes for b in codes)
    best = math.inf
    for k, o in itertools.product(words, repeat=2):
        codes = [*known.values(), k, o]
        if len(set(codes)) == 5 and not prefix(codes):
            lengths = {**{key: len(v) for key, v in known.items()}, "К": len(k), "О": len(o)}
            best = min(best, sum(lengths[c] for c in word))
    return best


def build_r(n) -> int:
    b = bin(n)[2:]
    return int(f"11{b}11" if n % 2 == 0 else f"1{b}00", 2)


def smallest_r(limit) -> int:
    return min(r for r in map(build_r, range(1, 5000)) if r > limit)


@lru_cache(maxsize=None)
def word_number(letters, even=True) -> int:
    order, skip, must = sorted(letters), sorted(letters)[:3], sorted(letters)[4]
    for number, word in enumerate(itertools.product(order, repeat=5), 1):
        if number % 2 == 0 and word[0] not in skip and must in word:
            return number


def _rows(seed) -> list[list[int]]:
    rng = random.Random(seed)
    return [[rng.randint(1, 60) for _ in range(5)] for _ in range(6)]


def row_ok(row) -> bool:
    return len(set(row)) == 5 and 2 * (max(row) + min(row)) > sum(row) - max(row) - min(row)


def network_sum(address: str, mask: str) -> int:
    return sum(int(a) & int(m) for a, m in zip(address.split("."), mask.split(".")))


def _mask(bits) -> str:
    value = (2 ** 32 - 1) ^ (2 ** (32 - bits) - 1)
    return ".".join(str(value >> s & 255) for s in (24, 16, 8, 0))


def _address(seed) -> str:
    rng = random.Random(seed)
    return ".".join(str(rng.randint(1, 254)) for _ in range(4))


def alphabet_power(length, numbers, kbytes) -> int:
    return 2 ** ((kbytes * 1024 // numbers) * 8 // length)


@lru_cache(maxsize=None)
def count_programs(start, finish) -> int:
    if start > finish:
        return 0
    if start == finish:
        return 1
    tens, units = start // 10 % 10, start % 10
    swapped = start - tens * 10 - units + units * 10 + tens
    return count_programs(start + 1, finish) + (count_programs(swapped, finish) if tens < units else 0)


def zeros(value, base) -> int:
    out = 0
    while value:
        value, digit = divmod(value, base)
        out += digit == 0
    return out


def _power_value(a, b, c):
    return a * 3125 ** 8 + 2 * 625 ** 7 - b * 625 ** 6 + 3 * 125 ** 5 - c * 25 ** 4 - 2025


def divisor_a(left, right, k) -> int:
    return math.gcd(*[x for x in range(left, right + 1) if x % k == 0])


def pair_count(numbers, m=7) -> int:
    low = min(numbers)
    return sum(a % m == low or b % m == low for a, b in zip(numbers, numbers[1:]))


def _numbers(seed) -> list[int]:
    rng = random.Random(seed)
    return [rng.randint(1, 40) for _ in range(12)]


@lru_cache(maxsize=None)
def game_value(a, b, limit, add) -> int:
    """Больше нуля: ходящий выигрывает за столько своих ходов. Меньше нуля: проигрывает за столько ходов соперника."""
    moves = ((a + add, b), (a, b + add), (a * 2, b), (a, b * 2))
    if any(x + y >= limit for x, y in moves):
        return 1
    values = [game_value(x, y, limit, add) for x, y in moves]
    losing = [v for v in values if v < 0]
    return 1 - max(losing) if losing else -max(values)


def game_19(heap, limit, add) -> int | None:
    for s in range(1, limit - heap):
        if game_value(heap, s, limit, add) != 1 and 1 in (game_value(heap + add, s, limit, add), game_value(heap, s + add, limit, add),
                                                          game_value(heap * 2, s, limit, add), game_value(heap, s * 2, limit, add)):
            return s
    return None


def game_first(heap, limit, add, value) -> int | None:
    return next((s for s in range(1, limit - heap) if game_value(heap, s, limit, add) == value), None)


def _processes(seed) -> list[tuple[int, int, tuple[int, ...]]]:
    rng, out = random.Random(seed), []
    for i in range(1, 7):
        out.append((i, rng.randint(2, 6), tuple(rng.sample(range(1, i), min(i - 1, rng.randint(0, 2))))))
    return out


def running(processes, moment) -> int:
    table = {pid: (time, deps) for pid, time, deps in processes}

    def end(pid) -> int:  # процесс может зависеть и от процесса ниже по таблице
        return max(map(end, table[pid][1]), default=0) + table[pid][0]

    return sum(end(pid) - table[pid][0] < moment <= end(pid) for pid in table)


def _weighted(seed) -> dict:
    rng, nodes = random.Random(seed), [1, 4, 6, 7, 12, 100]
    return {(a, b): rng.randint(10, 150) / 10 for a, b in itertools.combinations(nodes, 2) if rng.random() < 0.6}


_EXPRESSION = re.compile(r"(?:0|[6-9][06789]*)(?:[-*](?:0|[6-9][06789]*))*")


def _symbols(seed) -> str:
    rng = random.Random(seed)
    return "".join(rng.choice("0678967-*") for _ in range(24))


def longest_expression(s) -> int:
    return max((j - i for i in range(len(s)) for j in range(i + 1, len(s) + 1) if _EXPRESSION.fullmatch(s, i, j)), default=0)


def mask_count(mask, divisor, limit) -> int:
    pattern = re.compile(mask.replace("?", r"\d").replace("*", r"\d*"))
    return sum(bool(pattern.fullmatch(str(x))) for x in range(divisor, limit + 1, divisor))


def backups(sizes, capacity) -> list[int]:
    out, used = [], 0
    for size in sizes:
        if used + size > capacity:
            out.append(used)
            used = 0
        used += size
    return out


def _journal(seed) -> list[tuple[int, int]]:
    rng, hour = random.Random(seed), 1
    lines = []
    for _ in range(7):
        lines.append((hour, rng.randint(20, 130) * 1000))
        hour += rng.randint(1, 3)
    return lines


def journal_sum(lines, capacity) -> int:
    sizes, hours = [s for _, s in lines], []
    used = 0
    for hour, size in lines:
        if used + size > capacity:
            hours.append((hour, used))
            used = 0
        used += size
    morning = sorted((size for hour, size in hours if hour < 12), reverse=True)
    return sum(morning[:2]) if len(morning) > 1 else 0


def _journal_text(seed) -> str:
    return "\n".join(f"{hour:02}:00:00 {size}" for hour, size in _journal(seed))


OGE_EXAM: list[Numeric] = [
    E("io1_1", "inf", "oge", "В кодировке каждый символ занимает {i} бит. Из текста удалили название предмета, а также лишние запятую и пробел. Размер текста уменьшился на {b} байт. Сколько букв в удалённом названии?",
      lambda i, n: n, how="Переведи байты в символы, затем вычти запятую и пробел.", derive=lambda i, n: {"b": (n + 2) * i // 8}, i=[8, 16, 32], n=(4, 12, 1)),
    E("io2_1", "inf", "oge", "Цифры закодированы символами: 1 это ~, 2 это #, 3 это # +, 4 это + ~ #, 5 это + #, 6 это ~ #. Расшифруй сообщение {m} и запиши цифры подряд.",
      lambda w: int("".join(map(str, _word(w)))), check=lambda w: decodings(_message(w)) == 1, how="Подбирай коды слева направо, расшифровка здесь одна.",
      derive=lambda w: {"m": " ".join(_message(w))}, w=(1, 9999, 1)),
    E("io3_1", "logic", "oge", "Напиши наименьшее натуральное x, для которого ложно высказывание: (НЕ (x ≥ {a}) И НЕ (x = {b})) ИЛИ (x ≤ {c}).",
      lambda a, b, c: next(x for x in range(1, 300) if not ((x < a and x != b) or x <= c)), how="ИЛИ ложно, когда ложны обе части. Проверяй числа по порядку.",
      a=(3, 30, 1), b=(2, 30, 1), c=(3, 30, 1)),
    E("io3_2", "logic", "oge", "Напиши наибольшее натуральное x, для которого истинно высказывание: (x < {a}) И НЕ (x чётное).",
      lambda a: a - 1 if a % 2 == 0 else a - 2, how="Нужно нечётное число меньше границы.", a=(10, 99, 1)),
    E("io4_1", "data", "oge", "Между пунктами построены дороги, длины в километрах: {r}. Определи длину кратчайшего пути между A и F.",
      lambda w: shortest(_roads(w), "A", "F"), "км", check=lambda w: shortest(_roads(w), "A", "F") is not None, how="Сравни длины всех путей из A в F или пройди по алгоритму Дейкстры.",
      derive=lambda w: {"r": _roads_text(w)}, w=(1, 9999, 1)),
    E("io5_1", "algo", "oge", "У исполнителя две команды: 1. умножь на {k}; 2. прибавь {d}. Составь алгоритм получения из числа {a} числа {t}, содержащий не более 5 команд. В ответе запиши только номера команд.",
      lambda a, k, d, p: int(_commands(p)), check=lambda a, k, d, p: len(programs(a, run_program(a, k, d, _commands(p)), k, d)) == 1,
      how="Удобно идти от конца: отнимай и дели, пока не придёшь к исходному числу.",
      derive=lambda a, k, d, p: {"t": run_program(a, k, d, _commands(p))}, a=(2, 6, 1), k=(2, 4, 1), d=(1, 5, 1), p=(0, 31, 1)),
    E("io6_1", "algo", "oge", "Программа:\n\ns = int(input())\nt = int(input())\nA = int(input())\nif (s > {l}) or (t > A):\n    print(\"YES\")\nelse:\n    print(\"NO\")\n\nПары (s, t) при запусках: {p}. Укажи наименьшее целое A, при котором программа напечатает YES ровно {k} раз.",
      lambda w, l, k: parameter(_pairs(w), l, k), check=lambda w, l, k: parameter(_pairs(w), l, k) not in (None, 0), how="Посчитай пары с s больше границы, затем подбери A по значениям t.",
      derive=lambda w, l, k: {"p": "; ".join(f"({s}, {t})" for s, t in _pairs(w))}, w=(1, 9999, 1), l=[0, 5, 8, 10], k=(3, 7, 1)),
    E("io7_1", "inf", "oge", "Фрагменты адреса файла закодированы цифрами: {f}. Файл {n} лежит на сервере {s}, протокол {p}. Запиши последовательность цифр, кодирующую адрес файла.",
      lambda w: int("".join(str(_url(w)[1][i]) for i in range(7))), check=lambda w: len(set(_url(w)[0])) == 7, how="Порядок частей адреса: протокол, ://, сервер, /, файл.",
      derive=lambda w: {"f": _url(w)[2], "n": _url(w)[0][5] + _url(w)[0][6], "s": _url(w)[0][2] + _url(w)[0][3], "p": _url(w)[0][0]}, w=(1, 9999, 1)),
    E("io8_1", "inf", "oge", "По запросу Кошки & (Собаки | Хомяки) найдено {u} тысяч страниц, по запросу Кошки & Собаки & Хомяки найдено {z} тысяч, по запросу Кошки & Собаки найдено {x} тысяч. Сколько тысяч страниц будет найдено по запросу Кошки & Хомяки?",
      lambda x, z, u: u - x + z, check=lambda x, z, u: u > x > z and u - x + z > z, how="Формула включений и исключений: A | B = A + B − A & B.", x=(200, 600, 10), z=(50, 190, 10), u=(620, 1000, 10)),
    E("io9_1", "data", "oge", "Схема дорог задана списком, по каждой можно ехать только в указанном направлении: {e}. Сколько существует различных путей из A в G?",
      lambda w: count_paths(_dag(w), "A", "G"), check=lambda w: count_paths(_dag(w), "A", "G") > 2, how="Для каждого города сложи числа путей в города, из которых в него ведут дороги.",
      derive=lambda w: {"e": ", ".join(f"{a}→{b}" for a, b in _dag(w))}, w=(1, 9999, 1)),
    E("io10_1", "num", "oge", "Вычисли значение выражения {x}₂ + {y}₈ + {z}₁₆. В ответе запиши десятичное число.",
      lambda a, b, c: a + b + c, how="Переведи каждое слагаемое в десятичную систему.", derive=lambda a, b, c: {"x": bin(a)[2:], "y": oct(b)[2:], "z": f"{c:X}"},
      a=(64, 255, 1), b=(64, 700, 1), c=(32, 300, 1)),
    E("io16_1", "algo", "oge", "Дана последовательность: {s}. Сколько чисел в восьмеричной записи четырёхзначны и оканчиваются на цифру {d}?",
      lambda w, d: octal_hits(_stream(w, d), d), check=lambda w, d: octal_hits(_stream(w, d), d) > 0, how="Четырёхзначные в восьмеричной записи: от 512 до 4095. Последняя цифра равна остатку от деления на 8.",
      derive=lambda w, d: {"s": ", ".join(map(str, _stream(w, d)))}, w=(1, 9999, 1), d=(1, 7, 1)),
    E("io16_2", "algo", "oge", "По алгоритму Евклида найди наибольший общий делитель чисел {a} и {b}.", lambda a, b: math.gcd(a, b), check=lambda a, b: math.gcd(a, b) > 1,
      how="Заменяй большее число остатком от деления на меньшее, пока остаток не станет нулём.", a=(30, 300, 6), b=(42, 400, 6)),
    E("io16_3", "algo", "oge", "Сколько простых чисел на отрезке от {a} до {b}?", lambda a, b: sum(map(_is_prime, range(a, b + 1))), check=lambda a, b: a < b and any(map(_is_prime, range(a, b + 1))),
      how="Проверь каждое число: простое делится только на 1 и на себя.", a=(2, 60, 1), b=(30, 99, 1)),
]

EGE_EXAM: list[Numeric] = [
    E("ie2_1", "logic", "ege", "Сколько единиц в столбце результата таблицы истинности функции F = {f}?", lambda e: sum(bool(EXPRESSIONS[e][1](*r)) for r in itertools.product((False, True), repeat=4)),
      how="Переменных четыре, значит строк 16. Посчитай F для каждой строки.", derive=lambda e: {"f": EXPRESSIONS[e][0]}, e=list(range(len(EXPRESSIONS)))),
    E("ie4_1", "inf", "ege", "Сообщения содержат буквы Б, К, Л, О, Н. Код удовлетворяет условию Фано. Известно: Б это 00, Н это 010, Л это 111. Сколько двоичных знаков нужно для слова {w}, если оно закодировано минимально возможным числом знаков?",
      lambda i: fano_length(FANO_WORDS[i]), how="Частой букве дай самый короткий свободный код, не забывая про условие Фано.", derive=lambda i: {"w": FANO_WORDS[i]}, i=list(range(len(FANO_WORDS)))),
    E("ie5_1", "num", "ege", "Алгоритм строит двоичную запись числа N. Если N чётное, к записи справа и слева дописывают по две единицы. Если N нечётное, справа дописывают два нуля, а слева единицу. Полученная запись это число R. Укажи наименьшее R, превышающее {t}.",
      lambda t: smallest_r(t), how="Перебери N и вычисли R для каждого.", t=(60, 400, 5)),
    E("ie6_1", "algo", "ege", "Черепаха стоит в начале координат, голова направлена вверх. Алгоритм:\nПовтори 6 [Вперёд {a} Направо 90 Вперёд {b} Направо 90]\nПоднять хвост\nВперёд {c} Направо 90 Вперёд {d} Налево 90\nОпустить хвост\nПовтори 6 [Вперёд {h} Направо 90 Вперёд {w} Направо 90]\nСколько точек с целыми координатами находится внутри пересечения двух фигур, включая границы?",
      lambda a, b, c, d, h, w: (b - d + 1) * (a - c + 1), check=lambda a, b, c, d, h, w: b > d and a > c and d + w > b and c + h > a, how="Найди границы пересечения прямоугольников и перемножь число целых точек по осям.",
      a=(15, 40, 1), b=(15, 40, 1), c=(2, 10, 1), d=(2, 10, 1), h=(50, 90, 1), w=(50, 90, 1)),
    E("ie7_1", "inf", "ege", "Запись оцифрована в формате стерео с частотой {f} Гц и глубиной {i} бит. Длительность {t} с. Определи наименьшее количество Кбайт для хранения записи без заголовка.",
      lambda f, i, t: math.ceil(2 * f * i * t / 8 / 1024), "Кбайт", how="Объём: каналы · частота · глубина · время. Затем дели на 8 и на 1024.", f=[8000, 16000, 32000, 48000], i=[8, 16, 24], t=(30, 180, 3)),
    E("ie8_1", "inf", "ege", "Все пятибуквенные слова из букв {a} записаны в алфавитном порядке и пронумерованы с единицы. Определи номер первого слова с чётным номером, которое не начинается с букв {s} и содержит хотя бы одну букву {m}.",
      lambda i: word_number(ALPHABETS[i]), how="Удобно перебрать слова программой itertools.product.",
      derive=lambda i: {"a": ", ".join(sorted(ALPHABETS[i])), "s": ", ".join(sorted(ALPHABETS[i])[:3]), "m": sorted(ALPHABETS[i])[4]}, i=list(range(len(ALPHABETS)))),
    E("ie9_1", "data", "ege", "Дана таблица, в каждой строке пять чисел:\n{r}\nСколько строк, где все числа различны и удвоенная сумма наибольшего и наименьшего чисел больше суммы трёх остальных?",
      lambda w: sum(map(row_ok, _rows(w))), check=lambda w: any(map(row_ok, _rows(w))), how="Для каждой строки проверь оба условия.",
      derive=lambda w: {"r": "\n".join(" ".join(map(str, row)) for row in _rows(w))}, w=(1, 9999, 1)),
    E("ie10_1", "net", "ege", "Дан адрес узла {a} и маска {m}. Найди адрес сети. В ответе укажи сумму октетов найденного адреса.",
      lambda w, b: network_sum(_address(w), _mask(b)), how="Адрес сети: поразрядная конъюнкция адреса и маски.", derive=lambda w, b: {"a": _address(w), "m": _mask(b)}, w=(1, 9999, 1), b=(16, 28, 1)),
    E("ie11_1", "inf", "ege", "Серийный номер состоит из {l} символов. На номер отведено одинаковое минимальное целое число байт, символы кодируются одинаковым минимальным числом бит. Для {n} номеров отведено не более {k} Кбайт. Определи максимальную мощность алфавита.",
      lambda l, n, k: alphabet_power(l, n, k), check=lambda l, n, k: alphabet_power(l, n, k) > 2 and alphabet_power(l, n, k) < 1e8, how="Найди байты на номер, затем биты на символ, округляя вниз.", l=(100, 200, 1), n=(4000, 16000, 50), k=(500, 1500, 5)),
    E("ie12_1", "algo", "ege", "На ленте записано двоичное представление числа {n} без ведущих нулей, головка стоит в ближайшей справа ячейке. Программа: q0 на λ пишет λ, идёт влево, переходит в q1. q1 на 0 и 1 не меняет символ и идёт влево. q1 на λ пишет 1, идёт влево, переходит в q2. q2 на λ останавливается. Запиши результат в десятичной системе.",
      lambda n: n + 2 ** n.bit_length(), how="Программа дописывает единицу слева от числа.", n=(100, 3000, 1)),
    E("ie13_1", "algo", "ege", "У исполнителя две команды. A: прибавь 1. B: поменяй местами две младшие цифры, применяется, только если цифра десятков меньше цифры единиц. Сколько существует программ, которые из числа {a} получают число {b}?",
      lambda a, b: count_programs(a, b), check=lambda a, b: count_programs(a, b) > 1, how="Считай число программ для каждого числа, начиная с исходного.", a=(100, 130, 1), b=(135, 160, 1)),
    E("ie14_1", "num", "ege", "Значение выражения {a} · 3125^8 + 2 · 625^7 − {b} · 625^6 + 3 · 125^5 − {c} · 25^4 − 2025 записали в системе счисления с основанием 25. Сколько значащих нулей в этой записи?",
      lambda a, b, c: zeros(_power_value(a, b, c), 25), how="Удобно перевести число программой: деление на 25 с остатком.", a=(2, 6, 1), b=(2, 6, 1), c=(2, 6, 1)),
    E("ie15_1", "logic", "ege", "ДЕЛ(n, m) значит, что n делится на m без остатка. Дан отрезок B = [{a}; {b}]. Для какого наибольшего натурального A выражение ДЕЛ(x, A) ∨ ((x ∈ B) → ¬ДЕЛ(x, {k})) истинно при любом целом положительном x?",
      lambda a, b, k: divisor_a(a, b, k), check=lambda a, b, k: any(x % k == 0 for x in range(a, b + 1)), how="Числа отрезка, кратные k, обязаны делиться на A. Значит, A это их НОД.", a=(50, 90, 1), b=(95, 130, 1), k=(11, 30, 1)),
    E("ie16_1", "algo", "ege", "F(1) = 1, F(n) = n · F(n − 1) при n > 1. Чему равно (F({n}) + {c} · F({m})) / F({l})?",
      lambda n, c: n * (n - 1) + c * (n - 1), how="Сократи факториалы, расписав F(n) через F(n − 2).", derive=lambda n, c: {"m": n - 1, "l": n - 2}, n=(100, 3000, 1), c=(2, 9, 1)),
    E("ie17_1", "algo", "ege", "Дана последовательность: {s}. Сколько пар соседних элементов, в которых остаток от деления на 7 хотя бы одного элемента равен минимальному элементу последовательности?",
      lambda w: pair_count(_numbers(w)), check=lambda w: pair_count(_numbers(w)) > 0, how="Найди минимум, затем проверь каждую пару.", derive=lambda w: {"s": ", ".join(map(str, _numbers(w)))}, w=(1, 9999, 1)),
    E("ie19_1", "algo", "ege", "Две кучи камней, первый ход Пети. За ход можно добавить в одну кучу {d} камня или удвоить одну кучу. Игра заканчивается, когда в двух кучах суммарно не менее {l} камней, выигрывает сделавший последний ход. В первой куче {h} камней, во второй S. Известно, что Ваня выиграл своим первым ходом. Укажи минимальное S.",
      lambda h, l, d: game_19(h, l, d), check=lambda h, l, d: game_19(h, l, d) is not None, how="Найди S, при котором Петя может неудачным ходом дать Ване выигрыш.", h=[13, 15, 17, 19], l=[97, 121, 133], d=[3, 4, 5]),
    E("ie20_1", "algo", "ege", "Две кучи камней, первый ход Пети. За ход можно добавить в одну кучу {d} камня или удвоить одну кучу. Игра заканчивается, когда в двух кучах суммарно не менее {l} камней, выигрывает сделавший последний ход. В первой куче {h} камней, во второй S. Найди наименьшее S, при котором Петя не может выиграть за один ход, но выигрывает вторым ходом при любой игре Вани.",
      lambda h, l, d: game_first(h, l, d, 2), check=lambda h, l, d: game_first(h, l, d, 2) is not None, how="Позиция выигрышная за два хода, если есть ход в проигрышную позицию.", h=[13, 15, 17, 19], l=[97, 121, 133], d=[3, 4, 5]),
    E("ie21_1", "algo", "ege", "Две кучи камней, первый ход Пети. За ход можно добавить в одну кучу {d} камня или удвоить одну кучу. Игра заканчивается, когда в двух кучах суммарно не менее {l} камней, выигрывает сделавший последний ход. В первой куче {h} камней, во второй S. Найди наименьшее S, при котором у Вани есть стратегия выиграть первым или вторым ходом, но нет стратегии выиграть только первым ходом.",
      lambda h, l, d: game_first(h, l, d, -2), check=lambda h, l, d: game_first(h, l, d, -2) is not None, how="Все ходы Пети должны вести в выигрышные для Вани позиции, и хотя бы один требует двух ходов.", h=[13, 15, 17, 19], l=[97, 121, 133], d=[3, 4, 5]),
    E("ie22_1", "algo", "ege", "Процессы: {p}. Каждый процесс начинается в самое раннее допустимое время, зависимый процесс ждёт окончания указанных. Нумерация миллисекунд начинается с 1. Сколько процессов выполняется на {t}-й мс?",
      lambda w, t: running(_processes(w), t), check=lambda w, t: running(_processes(w), t) > 0, how="Для каждого процесса найди начало: на 1 мс позже конца самой поздней зависимости.",
      derive=lambda w, t: {"p": "; ".join(f"{i}: {m} мс, зависит от {', '.join(map(str, d)) or 'нет'}" for i, m, d in _processes(w))}, w=(1, 9999, 1), t=(2, 9, 1)),
    E("ie23_1", "data", "ege", "Рёбра ориентированного взвешенного графа: {e}. Запиши целую часть длины кратчайшего пути из вершины 1 в вершину 100.",
      lambda w: int(shortest(_weighted(w), 1, 100)), check=lambda w: (shortest(_weighted(w), 1, 100) or 0) >= 1, how="Алгоритм Дейкстры или перебор всех путей.",
      derive=lambda w: {"e": ", ".join(f"{a}→{b} {str(c).replace('.', ',')}" for (a, b), c in _weighted(w).items())}, w=(1, 9999, 1)),
    E("ie24_1", "algo", "ege", "Дана строка: {s}. Определи наибольшую длину непрерывной части, которая является корректным выражением с целыми неотрицательными числами: два знака не стоят рядом, в числах нет ведущих нулей.",
      lambda w: longest_expression(_symbols(w)), check=lambda w: longest_expression(_symbols(w)) > 2, how="Разбей строку на участки и проверь границы чисел и знаков.", derive=lambda w: {"s": _symbols(w)}, w=(1, 9999, 1)),
    E("ie25_1", "algo", "ege", "Символ ? означает ровно одну цифру, * любую последовательность цифр, в том числе пустую. Сколько чисел, не превышающих 1000000, соответствует маске {m} и делятся на {d}?",
      lambda i, d: mask_count(("1?2*5", "3?1*", "2*4?", "7?*5")[i], d, 10 ** 6), check=lambda i, d: mask_count(("1?2*5", "3?1*", "2*4?", "7?*5")[i], d, 10 ** 6) > 0,
      how="Перебери числа, кратные делителю, и проверь каждое по маске.", derive=lambda i, d: {"m": ("1?2*5", "3?1*", "2*4?", "7?*5")[i]}, i=[0, 1, 2, 3], d=(101, 999, 1)),
    E("ie26_1", "algo", "ege", "Сервер записывает данные в раздел вместимостью {k} Кбайт. Если для запроса не хватает памяти, он создаёт резервную копию всех накопленных данных, очищает раздел и продолжает работу. Журнал, время и объём в Кбайт:\n{j}\nНайди сумму объёмов двух наибольших резервных копий, созданных не позднее 11:59:59.",
      lambda w, k: journal_sum(_journal(w), k), "Кбайт", check=lambda w, k: journal_sum(_journal(w), k) > 0, how="Иди по журналу и копи объём, а при переполнении запоминай копию.",
      derive=lambda w, k: {"j": _journal_text(w)}, w=(1, 9999, 1), k=[140000, 160000, 200000]),
]

EXAM_NUMERIC = [*OGE_EXAM, *EGE_EXAM]
# Один номер экзамена, одна строка. Задания на файлы и рисунки в план не входят
EXAM_VARIANTS = {
    "oge": [("io1_1",), ("io2_1",), ("io3_1", "io3_2"), ("io4_1",), ("io5_1",), ("io6_1",), ("io7_1",), ("io8_1",), ("io9_1",), ("io10_1",),
            ("io16_1", "io16_2", "io16_3")],
    "ege": [(f"ie{n}_1",) for n in (2, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 19, 20, 21, 22, 23, 24, 25, 26)],
}
