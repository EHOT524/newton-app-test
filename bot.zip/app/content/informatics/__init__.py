from dataclasses import replace

from .dependencies import INFO_DEPENDENCIES
from .exam import EXAM_NUMERIC, EXAM_VARIANTS as INFO_VARIANTS
from .formulas import INFO_FORMULAS as _FORMULAS
from .formulas import NOT_IN_OGE
from .numeric import INFO_NUMERIC as _BASE_NUMERIC
from .problems import INFO_PROBLEMS as _PROBLEMS
from .terms import INFO_TERMS

INFO_TOPICS = {
    "inf": "💾 Информация и кодирование",
    "num": "🔢 Системы счисления",
    "logic": "🧠 Логика",
    "algo": "👾 Алгоритмы и программирование",
    "data": "🕸 Графы, таблицы и базы данных",
    "net": "🌐 Компьютерные сети",
}

INFO_FORMULAS = [replace(f, oge=False) if f.id in NOT_IN_OGE else f for f in _FORMULAS]
INFO_PROBLEMS = [replace(p, oge=False) if set(p.formulas) & NOT_IN_OGE else p for p in _PROBLEMS]
INFO_NUMERIC = [*_BASE_NUMERIC, *EXAM_NUMERIC]
