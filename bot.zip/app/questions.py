"""Генерация вопросов и проверка ответов."""

import itertools
import random
import re
from dataclasses import dataclass, field
from html import escape

from .content import (
    COURSES, DEPENDENCIES, INFO, LEVEL_OPTIONS, NUMERIC_BY_ID, Opened, PHYS, PROBLEMS, Numeric, Step, TERMS, numeric_for, numeric_topic,
    FORMULA_BY_ID, RELATIONS, Dependency, Formula, Problem, Term, STATEMENTS,
    deps_for, formulas_for, problems_for, terms_for,
)
from .formula_check import LOGIC_SIGNS, formula_matches, lev, token_matches, typed_form

OPERATORS = {"=", "·", "/", "+", "−", "(", ")", "√", "^", "sin", "cos", "'", "log_a", "log_b", "log_c", "log_2", *LOGIC_SIGNS}
GAP = "⬜"
LETTERS = "АБВГДЕЖЗ"

# Как набрать буквы, которых нет на клавиатуре телефона
LETTERS_HINT = ("υ (скорость) — <code>v</code>, V (объём) — большая <code>V</code>, ρ — <code>ро</code> или <code>p</code>, λ — <code>лямбда</code>, η — <code>эта</code> или <code>n</code>, "
                "ν — <code>ню</code> или <code>v</code>, μ — <code>мю</code>, ω — <code>омега</code> или <code>w</code>, "
                "φ — <code>фи</code>, Φ — <code>Ф</code>, Δ — <code>дельта</code>, ε — <code>эпсилон</code> или <code>e</code>, ε₀ — <code>эпсилон0</code> или <code>e0</code>, "
                "ℰ (ЭДС) — <code>E</code>, α — <code>альфа</code> или <code>a</code>, π — <code>пи</code> или <code>pi</code>")

TYPING_SHORT = ("<b>Как писать:</b>\n"
                "• дробь: числитель и знаменатель в скобках: <code>(m*v^2)/(2)</code>, <code>(Q1-Q2)/(Q1)</code>\n"
                "• корень: <code>sqrt(l/g)</code> или <code>корень(l/g)</code>\n"
                "• степень: <code>v^2</code>, индекс: <code>v0</code>, <code>m1</code>, <code>Fтр</code>\n"
                "• КПД: в конце <code>*100%</code>\n"
                "• греческие буквы — словом: <code>лямбда</code>, <code>ро</code>, <code>пи</code>. Весь список: /input")

TYPING_SHORT_MATH = ("<b>Как писать:</b>\n"
                     "• дробь: числитель и знаменатель в скобках: <code>(a+b)/(2)</code>\n"
                     "• корень: <code>sqrt(a)</code> или <code>корень(a)</code>\n"
                     "• степень: <code>x^2</code>, индекс: <code>x1</code>, <code>an</code>\n"
                     "• тригонометрия и логарифмы: <code>sin(a)</code>, <code>tg(a)</code>, <code>log_a(b)</code>, <code>ln(x)</code>\n"
                     "• греческие буквы — словом: <code>альфа</code>, <code>пи</code>. Весь список: /input")

TYPING_SHORT_INFO = ("<b>Как писать:</b>\n"
                     "• дробь: числитель и знаменатель в скобках: <code>(b-a)/(h)</code>\n"
                     "• степень: <code>2^i</code>, индекс: <code>a1</code>, <code>Iбайт</code>\n"
                     "• логарифм: <code>log_2(N)</code>\n"
                     "• логика: <code>не</code>, <code>и</code>, <code>или</code>, <code>-></code>, <code>==</code>, <code>xor</code>. "
                     "Пиши обе части равенства. Весь список: /input")

TYPING_HELP = ("✍️ <b>Как вводить формулы</b>\n\n"
               "<b>Дробь.</b> Перед дробной чертой — числитель в скобках, после неё — знаменатель в скобках:\n"
               "<code>(числитель)/(знаменатель)</code>\n"
               "Например, <code>R = (m*v)/(q*B)</code>. Если написать <code>m*v/q*B</code>, "
               "B окажется в числителе, и это будет другая формула.\n\n"
               "<b>Корень.</b> <code>sqrt(...)</code> или <code>корень(...)</code>, всё под корнем — в скобках:\n"
               "<code>T = 2*pi*sqrt(l/g)</code>\n\n"
               "<b>Степень.</b> <code>v^2</code>, можно <code>v²</code>.\n"
               "<b>Степень числа.</b> <code>2^(-t/T)</code>\n"
               "<b>Умножение.</b> <code>*</code>, можно без знака: <code>mgh</code>.\n"
               "<b>Индекс.</b> Сразу после буквы: <code>v0</code>, <code>m1</code>, <code>Fтр</code>, <code>Aвых</code>.\n"
               "<b>Синус и косинус.</b> <code>sin(a)</code>, <code>cos(a)</code>.\n"
               "<b>КПД.</b> В конце обязательно <code>*100%</code>: <code>эта = (Aп/Aз)*100%</code>.\n\n"
               f"<b>Греческие буквы, которых нет на клавиатуре телефона.</b> Пиши название русскими буквами или похожую латинскую букву:\n{LETTERS_HINT}\n\n"
               "Большие и маленькие буквы важны, только если в формуле есть обе, например T и t. "
               "Порядок множителей не важен, русские и английские буквы можно смешивать.")

TYPING_HELP_MATH = ("✍️ <b>Как вводить формулы</b>\n\n"
                    "<b>Дробь.</b> Числитель и знаменатель в скобках: <code>(a+b)/(2)</code>. "
                    "Если написать <code>a+b/2</code>, на 2 разделится только b.\n\n"
                    "<b>Корень.</b> <code>sqrt(D)</code> или <code>корень(D)</code>.\n"
                    "<b>Степень.</b> <code>x^2</code>, можно <code>x²</code>; со сложным показателем: <code>a^(m+n)</code>.\n"
                    "<b>Умножение.</b> <code>*</code>, можно без знака: <code>2ab</code>.\n"
                    "<b>Индекс.</b> Сразу после буквы: <code>x1</code>, <code>a1</code>, <code>an</code>, <code>Sбок</code>.\n"
                    "<b>Тригонометрия.</b> <code>sin(a)</code>, <code>cos(a)</code>, <code>tg(a)</code>, <code>ctg(a)</code>, "
                    "квадрат: <code>sin^2(a)</code>.\n"
                    "<b>Логарифм.</b> Основание после черты: <code>log_a(b)</code>, <code>log_2(8)</code>, а ещё <code>ln(x)</code>.\n"
                    "<b>Производная.</b> Штрих: <code>(x^n)'</code>, можно написать только правую часть.\n"
                    "<b>Тождества.</b> Пиши обе части равенства: <code>(a+b)^2 = a^2+2ab+b^2</code>.\n\n"
                    "<b>Греческие буквы.</b> α — <code>альфа</code> или <code>a</code>, β — <code>бета</code> или <code>b</code>, "
                    "γ — <code>гамма</code>, π — <code>пи</code> или <code>pi</code>, φ — <code>фи</code>.\n\n"
                    "Большие и маленькие буквы важны, только если в формуле есть обе, например S и s. "
                    "Порядок множителей не важен, русские и английские буквы можно смешивать.")
TYPING_HELP_INFO = ("✍️ <b>Как вводить формулы</b>\n\n"
                    "<b>Дробь.</b> Числитель и знаменатель в скобках: <code>k = (b-a)/(h) + 1</code>.\n"
                    "<b>Степень.</b> <code>2^i</code>, со сложным показателем: <code>2^(32-m)</code>.\n"
                    "<b>Умножение.</b> <code>*</code>, можно без знака: <code>xyi</code>.\n"
                    "<b>Логарифм.</b> <code>log_2(N)</code>.\n"
                    "<b>Индекс.</b> Сразу после буквы: <code>I1</code>, <code>a2</code>, <code>Iбайт</code>.\n\n"
                    "<b>Логика.</b> Пиши обе части равенства, а буквы большими или маленькими, как удобно:\n"
                    "НЕ — <code>не</code>, <code>not</code> или <code>!</code>\n"
                    "И — <code>и</code>, <code>and</code> или <code>&</code>\n"
                    "ИЛИ — <code>или</code>, <code>or</code> или <code>|</code>\n"
                    "Импликация — <code>-></code>\n"
                    "Эквиваленция — <code>==</code>\n"
                    "Исключающее ИЛИ — <code>xor</code>\n"
                    "Например: <code>A -> B = не A или B</code>\n\n"
                    "Большие и маленькие буквы важны, только если в формуле есть обе, например I и i.")
TYPING = {"phys": TYPING_HELP, "math": TYPING_HELP_MATH, "info": TYPING_HELP_INFO}
TYPING_SHORT_BY_SUBJECT = {"phys": TYPING_SHORT, "math": TYPING_SHORT_MATH, "info": TYPING_SHORT_INFO}


@dataclass
class Question:
    kind: str              # тип упражнения (для заголовка)
    text: str              # HTML
    key: str               # ключ объекта для «работы над ошибками»
    explanation: str       # HTML, показывается после ответа
    options: list[str] = field(default_factory=list)  # пусто → ответ вводится текстом
    correct: int = -1      # индекс правильного варианта
    accept: list[str] = field(default_factory=list)   # для текстового ответа
    check: str = ""        # "formula" | "formulas" | "token" | "word" | "digits" | "relation" | "number"
    context: list[str] = field(default_factory=list)  # все токены формулы для проверки пропуска
    groups: list[list[str]] = field(default_factory=list)  # для задачи: записи каждой нужной формулы
    value: float = 0.0     # числовой ответ
    tolerance: float = 0.0
    repeat: bool = False   # повтор вопроса, на который ошиблись в этом же уроке

    @property
    def typed(self) -> bool:
        return not self.options

    @property
    def answer_text(self) -> str | None:
        if self.options:
            return self.options[self.correct]
        if self.check in ("token", "word", "digits", "relation", "number"):
            return self.accept[0]
        return None  # для «напиши формулу» ответ уже в пояснении


# ---------- отображение формул ----------

def tokens(expr: str) -> list[str]:
    return expr.split(" ")


def render(toks: list[str]) -> str:
    out, prev, prev2 = "", None, None
    for t in toks:
        unary_minus = prev == "−" and prev2 in (None, "=", "(", "^")
        glue = prev is None or prev in ("(", "√", "^", "¬") or t in (")", "^", "'") or unary_minus
        out += t if glue else " " + t
        prev2, prev = prev, t
    return out.replace(")^2", ")²").replace(")^3", ")³")


def render_expr(expr: str) -> str:
    return render(tokens(expr))


def maskable(toks: list[str]) -> list[int]:
    return [i for i, t in enumerate(toks) if t not in OPERATORS]


# ---------- проверка текстовых ответов ----------

def norm_word(s: str) -> str:
    s = s.lower().replace("ё", "е")
    return re.sub(r"[^\w]", "", s)


def relation_key(s: str) -> tuple[str, str]:
    """Прямо/обратно и степень: «обратно пропорционально квадрату» → (inv, sq)."""
    s = s.lower()
    if "завис" in s or s.strip() == "нет":
        return "none", ""
    if "линейн" in s:
        return "linear", ""
    kind = "inv" if "обр" in s else "dir" if "пр" in s else ""
    return kind, "sqrt" if "кор" in s else "sq" if "квадрат" in s else "cube" if "куб" in s else ""


def formulas_match(answer: str, groups: list[list[str]]) -> bool:
    parts = [p.strip() for p in re.split(r"[;\n]|,(?!\d)", answer) if p.strip()]
    return len(parts) == len(groups) and any(
        all(formula_matches(p, g) for p, g in zip(perm, groups)) for perm in itertools.permutations(parts))


_NUMBER = re.compile(r"-?\d+(?:\.\d+)?")
_POWER = re.compile(r"\s*[*·×xх]\s*10\s*\^?\s*(-?\d+)")
_FRACTION = re.compile(r"\s*/\s*([1-9]\d*)(?![\d.])")


def parse_number(answer: str) -> float | None:
    """Первое число ответа: допускаем 12,5 м/с, v = 12.5, 1 200, 3*10^8 и 3/4."""
    s = answer.lower().rsplit("=", 1)[-1].replace("−", "-").replace("–", "-").replace(",", ".")
    s = re.sub(r"(?<=\d)\s+(?=\d)", "", s)
    m = _NUMBER.search(s)
    if not m:
        return None
    power = _POWER.match(s, m.end())
    fraction = _FRACTION.match(s, m.end())
    return float(m.group()) * (10.0 ** int(power.group(1)) if power else 1) / (int(fraction.group(1)) if fraction else 1)


def check_typed(q: Question, answer: str) -> bool:
    if q.check == "number":
        number = parse_number(answer)
        return number is not None and abs(number - q.value) <= q.tolerance
    if q.check == "formula":
        return formula_matches(answer, q.accept)
    if q.check == "formulas":
        return formulas_match(answer, q.groups)
    if q.check == "relation":
        return relation_key(answer) == relation_key(q.accept[0])
    if q.check == "token":
        return token_matches(answer, q.accept[0], q.context)
    if q.check == "digits":
        return sorted(re.findall(r"\d", answer)) == sorted(q.accept[0])
    if q.check == "word":
        a = norm_word(answer)
        for ok in q.accept:
            ok = norm_word(ok)
            if a == ok or (len(ok) >= 6 and lev(a, ok) <= (1 if len(ok) < 15 else 2)):
                return True
    return False


# ---------- помощники ----------

def _options(correct: str, pool: list[str], total: int = 4, extra: list[str] = ()) -> tuple[list[str], int]:
    """Правильный ответ и неверные: сначала из pool, если не хватило — из extra."""
    near = [p for p in dict.fromkeys(pool) if p != correct]
    far = [p for p in dict.fromkeys(extra) if p != correct and p not in near]
    random.shuffle(near)
    random.shuffle(far)
    opts = (near + far)[:total - 1] + [correct]
    random.shuffle(opts)
    return opts, opts.index(correct)


def _same_topic(f: Formula, pool: list[Formula]) -> list[Formula]:
    same = [x for x in pool if x.topic == f.topic and x.id != f.id]
    every = COURSES[f.subject].formulas
    if len(same) < 8:
        same += [x for x in every if x.topic == f.topic and x.id != f.id and x not in same]
    if len(same) < 8:
        same += [x for x in every if x.id != f.id and x not in same]
    return same


# ---------- генераторы: формулы ----------

def _formula_card(f: Formula) -> str:
    card = f"<b>{escape(render_expr(f.expr))}</b>\nКак набрать: <code>{escape(typed_form(f.expr))}</code>"
    if f.alts:
        card += "\nТакже верно: " + ", ".join(escape(render_expr(a)) for a in f.alts)
    return card


def q_formula_gap(f: Formula) -> Question:
    toks = tokens(f.expr)
    i = random.choice(maskable(toks))
    shown = render(toks[:i] + [GAP] + toks[i + 1:])
    text = f"🧩 <b>Дополни формулу</b>\n{escape(f.name)}\n\n<b>{escape(shown)}</b>\n\n✍️ Напиши, что стоит вместо {GAP}."
    if f.subject != INFO:
        text += ("\n\nЕсли там греческая буква, которой нет на клавиатуре телефона, напиши её название русскими буквами: "
                 + ("ρ — <code>ро</code>, λ — <code>лямбда</code>, π — <code>пи</code>." if f.subject == PHYS
                    else "α — <code>альфа</code>, π — <code>пи</code>.") + " Как писать остальные: /input")
    return Question("Дополни формулу", text, f"f:{f.id}", _formula_card(f),
                    accept=[toks[i]], check="token", context=toks)


def q_formula_write(f: Formula) -> Question:
    text = f"✍️ <b>Напиши формулу</b>\n\n«{escape(f.name)}»\n\n{TYPING_SHORT_BY_SUBJECT[f.subject]}"
    return Question("Напиши формулу", text, f"f:{f.id}", _formula_card(f),
                    accept=[f.expr, *f.alts], check="formula")


def _shuffled(*groups):
    for group in groups:
        yield from random.sample(list(group), len(group))


def q_formula_choose(f: Formula, pool: list[Formula], total: int) -> Question:
    """Выбрать формулу по названию: неверные варианты — другие формулы той же темы."""
    accept = [f.expr, *f.alts]
    wrong: list[str] = []
    for x in _shuffled(_same_topic(f, pool), COURSES[f.subject].formulas):
        shown = render_expr(x.expr)
        if len(wrong) == total - 1:
            break
        if shown not in wrong and x.id != f.id and not formula_matches(x.expr, accept):
            wrong.append(shown)
    opts, correct = _options(render_expr(f.expr), wrong, total)
    text = f"🧮 <b>Выбери формулу</b>\n\n«{escape(f.name)}»"
    return Question("Выбери формулу", text, f"f:{f.id}", _formula_card(f), options=opts, correct=correct)


def q_formula_gap_choose(f: Formula, pool: list[Formula], total: int) -> Question:
    """Выбрать, что стоит вместо пропуска, так чтобы другой вариант не давал верную формулу."""
    toks = tokens(f.expr)
    i = random.choice(maskable(toks))
    accept = [f.expr, *f.alts]
    own = [t for t in toks if t not in OPERATORS]
    near = [t for x in _same_topic(f, pool) for t in tokens(x.expr) if t not in OPERATORS]
    every = [t for x in COURSES[f.subject].formulas for t in tokens(x.expr) if t not in OPERATORS]
    wrong: list[str] = []
    for t in _shuffled(dict.fromkeys(own), dict.fromkeys(near), dict.fromkeys(every)):
        if len(wrong) == total - 1:
            break
        if t != toks[i] and t not in wrong and not token_matches(t, toks[i], toks) \
                and not formula_matches(" ".join(toks[:i] + [t] + toks[i + 1:]), accept):
            wrong.append(t)
    opts, correct = _options(toks[i], wrong, total)
    shown = render(toks[:i] + [GAP] + toks[i + 1:])
    text = f"🧩 <b>Дополни формулу</b>\n{escape(f.name)}\n\n<b>{escape(shown)}</b>\n\nВыбери, что стоит вместо {GAP}."
    return Question("Дополни формулу", text, f"f:{f.id}", _formula_card(f), options=opts, correct=correct)


def random_formula_question(f: Formula, pool: list[Formula], total: int = 0) -> Question:
    gap = random.random() < 0.6
    if total:
        return q_formula_gap_choose(f, pool, total) if gap else q_formula_choose(f, pool, total)
    return q_formula_gap(f) if gap else q_formula_write(f)


# ---------- генераторы: задачи ----------

def _combo(ids) -> str:
    return ";  ".join(render_expr(FORMULA_BY_ID[i].expr) for i in ids)


def q_problem(p: Problem, idx: int, pool: list[Formula], total: int = 4) -> Question:
    right = list(p.formulas)
    expl = f"Формулы: <b>{escape(_combo(right))}</b>\nОтвет: <b>{escape(p.answer)}</b>"
    if not total:
        many = "Напиши все нужные формулы через точку с запятой. " if len(right) > 1 else "Напиши нужную формулу. "
        text = f"📝 <b>Задача</b>\n\n{escape(p.text)}\n\n{many}Как вводить формулы: /input"
        groups = [[FORMULA_BY_ID[i].expr, *FORMULA_BY_ID[i].alts] for i in right]
        return Question("Задача", text, f"p:{idx}", expl, check="formulas", groups=groups)
    related = [x.id for f in right for x in _same_topic(FORMULA_BY_ID[f], pool) if x.id not in right]
    related = list(dict.fromkeys(related))
    variants = []
    for _ in range(300):
        v = right.copy()
        pos = random.randrange(len(v))
        v[pos] = random.choice(related)
        if len(v) > 1 and random.random() < 0.3:
            v.pop(random.randrange(len(v)))  # «забытая» формула
        if len(set(v)) == len(v) and set(v) != set(right):
            variants.append(_combo(v))
        if len(set(variants)) >= total - 1:
            break
    opts, correct = _options(_combo(right), variants, total)
    text = f"📝 <b>Задача</b>\n\n{escape(p.text)}\n\nКакие формулы понадобятся для решения?"
    return Question("Задача", text, f"p:{idx}", expl, options=opts, correct=correct)


# ---------- генераторы: термины ----------

def q_term_by_def(t: Term, pool: list[Term], total: int = 4) -> Question:
    definition = f"<i>{escape(t.definition[:1].upper() + t.definition[1:])}</i>"
    if not total:
        text = f"📖 <b>Напиши термин по определению</b>\n\n{definition}"
        return Question("Термин", text, f"t:{t.term}", _term_card(t), accept=[t.term], check="word")
    opts, correct = _options(t.term, [x.term for x in pool], total, [x.term for x in COURSES[t.subject].terms])
    text = f"📖 <b>Какой термин подходит под определение?</b>\n\n{definition}"
    return Question("Термин", text, f"t:{t.term}", _term_card(t), options=opts, correct=correct)


def q_def_by_term(t: Term, pool: list[Term], total: int = 4) -> Question:
    opts, correct = _options(t.definition, [x.definition for x in pool], total,
                             [x.definition for x in COURSES[t.subject].terms])
    text = f"📖 <b>Выбери определение</b>\n\n<b>{escape(t.term)}</b> — это…"
    return Question("Определение", text, f"t:{t.term}", _term_card(t), options=opts, correct=correct)


def q_term_blank(t: Term, pool: list[Term], total: int = 0) -> Question:
    gap = t.definition.replace(t.blank, "_____", 1)
    if total:
        opts, correct = _options(t.blank, [x.blank for x in pool], total, [x.blank for x in COURSES[t.subject].terms])
        text = f"📖 <b>Выбери пропущенное слово</b>\n\n<b>{escape(t.term)}</b> — {escape(gap)}"
        return Question("Пропущенное слово", text, f"t:{t.term}", _term_card(t), options=opts, correct=correct)
    text = (f"✍️ <b>Впиши пропущенное слово</b>\n\n<b>{escape(t.term)}</b> — {escape(gap)}\n\n"
            "Напиши одно слово в нужной форме.")
    return Question("Пропущенное слово", text, f"t:{t.term}", _term_card(t), accept=[t.blank], check="word")


def _term_card(t: Term) -> str:
    return f"<b>{escape(t.term)}</b> — {escape(t.definition)}"


def random_term_question(t: Term, pool: list[Term], total: int = 0) -> Question:
    r = random.random()
    if r < 0.4:
        return q_term_by_def(t, pool, total)
    if r < 0.65 and total:
        return q_def_by_term(t, pool, total)
    return q_term_blank(t, pool, total)


# ---------- генераторы: зависимости ----------

def dependency_card(d: Dependency) -> str:
    cond = f" ({escape(d.condition)})" if d.condition else ""
    return (f"🔗 <b>{escape(d.quantity[:1].upper() + d.quantity[1:])}</b> — от {escape(d.on)}: "
            f"<b>{escape(d.relation)}</b>{cond}\n"
            f"Почему: <code>{escape(d.formula)}</code>")


def q_dependency(d: Dependency, pool: list[Dependency], total: int = 0) -> Question:
    cond = f" ({escape(d.condition)})" if d.condition else ""
    text = f"🔗 <b>Зависимость</b>\n\nКак <b>{escape(d.quantity)}</b> зависит от <b>{escape(d.on)}</b>{cond}?"
    if not total:
        text += ("\n\n✍️ Напиши словами: прямо или обратно пропорционально, при необходимости добавь "
                 "«квадрату» или «корню». Если связи нет: <code>не зависит</code>")
        return Question("Зависимость", text, f"d:{d.key}", dependency_card(d), accept=[d.relation], check="relation")
    opts, correct = _options(d.relation, RELATIONS, total)
    return Question("Зависимость", text, f"d:{d.key}", dependency_card(d), options=opts, correct=correct)


# ---------- генераторы: задание 18 ЕГЭ ----------

STATEMENT_LAYOUT = ("mech", "mol", "el", "el", "quant")  # как в экзаменационном задании


def q_statements(idxs: list[int], total: int = 0) -> Question:
    items = [STATEMENTS[i] for i in idxs]
    lines = "\n\n".join(f"<b>{n})</b> {escape(s.text)}" for n, s in enumerate(items, 1))
    text = f"🎓 <b>Задание 18 ЕГЭ</b>\n\nВыбери все верные утверждения:\n\n{lines}"
    expl = "\n".join(f"{n}) ✅ верно" if s.true else f"{n}) ❌ неверно: {escape(s.why)}"
                     for n, s in enumerate(items, 1))
    digits = "".join(str(n) for n, s in enumerate(items, 1) if s.true)
    key = "s:" + "-".join(map(str, idxs))
    if total:
        combos = ["".join(c) for size in (2, 3) for c in itertools.combinations("12345", size)]
        opts, correct = _options(digits, combos, total)
        return Question("Задание 18", text + "\n\nВыбери номера верных утверждений.", key, expl,
                        options=opts, correct=correct)
    text += "\n\n✍️ Напиши номера верных утверждений, например <code>135</code>"
    return Question("Задание 18", text, key, expl, accept=[digits], check="digits")


def _statement_task(rng) -> Question:
    """Задание 18 для варианта: один и тот же номер варианта даёт одни и те же утверждения."""
    pools: dict[tuple[str, bool], list[int]] = {}
    for i, s in enumerate(STATEMENTS):
        pools.setdefault((s.section, s.true), []).append(i)
    for pool in pools.values():
        rng.shuffle(pool)
    true_slots = rng.sample(range(5), rng.choice((2, 3)))
    return q_statements([pools[sec, slot in true_slots].pop() for slot, sec in enumerate(STATEMENT_LAYOUT)])


def build_statements(mode: str, size: int, total: int = 0, subject: str = PHYS) -> list[Question]:
    if mode != "ege" or subject != PHYS:
        return []
    pools: dict[tuple[str, bool], list[int]] = {}
    for i, s in enumerate(STATEMENTS):
        pools.setdefault((s.section, s.true), []).append(i)
    for pool in pools.values():
        random.shuffle(pool)
    out = []
    for _ in range(max(1, size // 2)):  # одно задание — это пять утверждений
        true_slots = random.sample(range(5), random.choice((2, 3)))
        wanted = [(sec, slot in true_slots) for slot, sec in enumerate(STATEMENT_LAYOUT)]
        if any(wanted.count(w) > len(pools.get(w, [])) for w in wanted):
            break
        out.append(q_statements([pools[w].pop() for w in wanted], total))
    return out


# ---------- генераторы: задачи с числовым ответом ----------

ROUND_WORDS = {0: "целых", 1: "десятых", 2: "сотых", 3: "тысячных"}
UNIT_WORDS = {"%": "процентах", "°": "градусах", "°C": "градусах Цельсия"}
VARIANT_SIZE = 15
VARIANTS = 20


def fmt(x: float) -> str:
    return f"{round(x, 6):.6f}".rstrip("0").rstrip(".").replace(".", ",")


def _draw(spec, rng) -> float:
    if isinstance(spec, list):
        return rng.choice(spec)
    lo, hi, step = spec
    return round(lo + step * rng.randint(0, round((hi - lo) / step)), 6)


def _rounding(value: float) -> int | None:
    """До какого разряда округлять; None, если ответ и так короткий."""
    if abs(value - round(value, 4)) < 1e-9:
        return None
    return 1 if abs(value) >= 100 else 2 if abs(value) >= 1 else 3


def q_number(t: Numeric, rng=random) -> Question:
    for _ in range(200):
        args = {k: _draw(spec, rng) for k, spec in t.ranges.items()}
        if t.check is None or t.check(**args):
            break
    else:
        raise ValueError(f"Не подобраны числа для задачи {t.id}")
    value = t.answer(**args)
    shown = {**args, **(t.derive(**args) if t.derive else {})}
    text = f"📐 <b>Задача</b>\n\n{escape(t.text.format(**{k: v if isinstance(v, str) else fmt(v) for k, v in shown.items()}))}\n\n"
    digits = _rounding(value)
    if digits is not None:
        text += f"Ответ округли до {ROUND_WORDS[digits]}. "
        tolerance = max(0.5 * 10 ** -digits, abs(value) * 0.002)  # промежуточное округление — не ошибка
        value = round(value, digits)
    else:
        tolerance = 1e-6
    if t.unit:
        text += f"Единицы ответа: {UNIT_WORDS.get(t.unit, t.unit.strip('·.'))}. "
    text += "\n✍️ Напиши только число."
    formulas = escape(t.how) or "\n".join(f"<b>{escape(render_expr(FORMULA_BY_ID[f].expr))}</b>" for f in t.formulas)
    answer = f"{fmt(value)}{t.unit}" if t.unit.startswith("·") else f"{fmt(value)} {t.unit}".strip()
    return Question("Задача", text, f"n:{t.id}", formulas, accept=[answer], check="digits" if t.any_order else "number",
                    value=value, tolerance=tolerance)


def _open_numeric(mode: str, topic: str | None, subject: str, only: Opened | None) -> list[Numeric]:
    pool = numeric_for(mode, topic, subject)
    return pool if only is None else [t for t in pool if set(t.formulas) <= only.formulas]


def test_topics(mode: str, subject: str = PHYS, only: Opened | None = None) -> list[str]:
    return [topic for topic in COURSES[subject].topics if _open_numeric(mode, topic, subject, only)]


def build_test(mode: str, topic: str, size: int, subject: str = PHYS, only: Opened | None = None) -> list[Question]:
    pool = _open_numeric(mode, topic, subject, only)
    picks: list[Numeric] = []
    while len(picks) < size:  # если шаблонов меньше, чем вопросов, повторяем их с другими числами
        picks += random.sample(pool, len(pool))
    return [q_number(t) for t in picks[:size]]


def variant_size(mode: str, subject: str = PHYS) -> int:
    plan = COURSES[subject].variants.get(mode, ())
    return sum(len(slot[0]) if isinstance(slot, list) else 1 for slot in plan) or VARIANT_SIZE


def _planned_variant(mode: str, plan: list, rng, subject: str) -> list[Question]:
    """Вариант по плану экзамена: в каждое задание берём ещё не использованную задачу."""
    by_id = {t.id: t for t in numeric_for(mode, None, subject)}
    used: set[str] = set()
    out: list[Question] = []
    for slot in plan:
        if slot == "statements":
            out.append(_statement_task(rng))
        elif isinstance(slot, list):  # блок: несколько номеров подряд на одну тему
            out += [q_number(by_id[i], rng) for i in rng.choice(slot)]
        else:
            chosen = rng.choice([i for i in slot if i in by_id and i not in used])
            used.add(chosen)
            out.append(q_number(by_id[chosen], rng))
    return out


def build_variant(mode: str, number: int, subject: str = PHYS) -> list[Question]:
    """Один номер варианта у всех один и тот же: числа задаются предметом, режимом и номером."""
    rng = random.Random(f"{mode}:{number}" if subject == PHYS else f"{subject}:{mode}:{number}")
    plan = COURSES[subject].variants.get(mode)
    if plan:
        return _planned_variant(mode, plan, rng, subject)
    pools = [numeric_for(mode, topic, subject) for topic in test_topics(mode, subject)]
    groups = [rng.sample(pool, len(pool)) for pool in pools]
    picks: list[Numeric] = []
    while len(picks) < VARIANT_SIZE and any(groups):
        for group in groups:  # задания идут по разделам, из каждого поровну
            if group and len(picks) < VARIANT_SIZE:
                picks.append(group.pop())
    order = list(COURSES[subject].topics)
    picks.sort(key=lambda t: order.index(numeric_topic(t)))
    return [q_number(t, rng) for t in picks]


# ---------- сборка урока ----------

CATEGORIES = {
    "mix": "🎯 Смешанный урок",
    "formulas": "🧮 Формулы",
    "problems": "📝 Задачи",
    "terms": "📖 Термины",
    "deps": "🔗 Зависимости",
    "statements": "🎓 Задание 18 ЕГЭ",
}


def build_lesson(category: str, mode: str, size: int, level: str = "hard", subject: str = PHYS,
                 only: Opened | None = None) -> list[Question]:
    total = LEVEL_OPTIONS[level]
    if category == "statements":
        return build_statements(mode, size, total, subject)
    fs, ts = formulas_for(mode, subject), terms_for(mode, subject)
    ds, ps = deps_for(mode, subject), problems_for(mode, subject)
    pidx = {id(p): i for i, p in enumerate(COURSES[subject].problems)}
    if only is not None:  # в пути пройденное видно, а закрытые темы в урок не попадают
        fs = [f for f in fs if f.id in only.formulas]
        ts = [t for t in ts if t.term in only.terms]
        ds = [d for d in ds if d.key in only.deps]
        ps = [p for p in ps if set(p.formulas) <= only.formulas]
    groups = {
        "formulas": [lambda f=f: random_formula_question(f, fs, total) for f in fs],
        "terms": [lambda t=t: random_term_question(t, ts, total) for t in ts],
        "deps": [lambda d=d: q_dependency(d, ds, total) for d in ds],
        "problems": [lambda p=p: q_problem(p, pidx[id(p)], fs, total) for p in ps],
    }
    if category != "mix":
        groups = {category: groups[category]}
    for g in groups.values():
        random.shuffle(g)
    # В смешанном уроке каждый вопрос берём из случайного раздела — так разделы чередуются
    out = []
    while len(out) < size:
        alive = [g for g in groups.values() if g]
        if not alive:
            break
        out.append(random.choice(alive).pop()())
    return out


def build_path_step(mode: str, step: Step, level: str, earlier: Opened | None, size: int) -> list[Question]:
    """Урок шага: всё новое из шага, числовые задачи на него и немного старого, чтобы оно не забывалось."""
    total = LEVEL_OPTIONS[level]
    if step.tasks:
        picks: list[str] = []
        while len(picks) < size:  # видов задач мало, поэтому повторяем их с другими числами
            picks += random.sample(step.tasks, len(step.tasks))
        out: list[Question] = []
        for i in picks[:size]:
            out.append(next((q for q in (q_number(NUMERIC_BY_ID[i]) for _ in range(30)) if q.text not in {o.text for o in out}), q_number(NUMERIC_BY_ID[i])))
        return out
    if not step.formulas and not step.terms and not step.deps:  # номер 18 ЕГЭ задан утверждениями, а не шаблонами
        return build_statements(mode, size * 2, total, PHYS)  # каждое задание забирает два места из size
    fs, ts, ds = formulas_for(mode), terms_for(mode), deps_for(mode)
    terms = {t.term: t for t in TERMS}
    known = set(earlier.formulas if earlier else ()) | set(step.formulas)
    pidx = {id(p): i for i, p in enumerate(PROBLEMS)}
    own = [lambda f=FORMULA_BY_ID[i]: random_formula_question(f, fs, total) for i in step.formulas]
    own += [lambda t=terms[name]: random_term_question(t, ts, total) for name in step.terms]
    own += [lambda d=DEPENDENCIES[i]: q_dependency(d, ds, total) for i in step.deps]
    tasks = [t for t in numeric_for(mode) if set(t.formulas) & set(step.formulas) and set(t.formulas) <= known]
    tasks = [lambda t=t: q_number(t) for t in random.sample(tasks, min(2, len(tasks)))]
    problems = [p for p in problems_for(mode) if set(p.formulas) & set(step.formulas) and set(p.formulas) <= known]
    problems = [lambda p=p: q_problem(p, pidx[id(p)], fs, total) for p in random.sample(problems, min(1, len(problems)))]
    old = []
    if earlier and not step.control:
        old = [lambda f=FORMULA_BY_ID[i]: random_formula_question(f, fs, total) for i in earlier.formulas]
        old += [lambda t=terms[name]: random_term_question(t, ts, total) for name in earlier.terms]
        old = random.sample(old, min(2, len(old)))
    random.shuffle(own)
    makers = [*tasks[:1], *own, *tasks[1:], *problems, *old][:size]
    repeat = own.copy()
    while len(makers) < min(size, 5):  # в маленьком шаге одно и то же спрашиваем разными способами
        makers.append(repeat[len(makers) % len(repeat)])
    random.shuffle(makers)
    return [make() for make in makers]


def build_review(keys: list[str], mode: str, size: int, level: str = "hard", subject: str = PHYS) -> list[Question]:
    total = LEVEL_OPTIONS[level]
    course = COURSES[subject]
    fs, ts, ds = formulas_for(mode, subject), terms_for(mode, subject), deps_for(mode, subject)
    terms = {t.term: t for t in course.terms}
    deps = {d.key: d for d in course.deps}
    keys = keys.copy()
    random.shuffle(keys)
    out = []
    for key in keys[:size]:
        kind, _, ref = key.partition(":")
        if kind == "f" and ref in FORMULA_BY_ID:
            out.append(random_formula_question(FORMULA_BY_ID[ref], fs or course.formulas, total))
        elif kind == "t" and ref in terms:
            out.append(random_term_question(terms[ref], ts or course.terms, total))
        elif kind == "d" and ref in deps:
            out.append(q_dependency(deps[ref], ds, total))
        elif kind == "s" and all(x.isdigit() and int(x) < len(STATEMENTS) for x in ref.split("-")):
            out.append(q_statements([int(x) for x in ref.split("-")], total))
        elif kind == "p" and ref.isdigit() and int(ref) < len(course.problems):
            out.append(q_problem(course.problems[int(ref)], int(ref), fs or course.formulas, total))
        elif kind == "n" and ref in NUMERIC_BY_ID:
            out.append(q_number(NUMERIC_BY_ID[ref]))
    return out
